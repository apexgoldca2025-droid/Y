# Project Guidance

## User Preferences

- Interfaz limpia en tonos blancos, negros y grises con un poco de verde
- Todo debe ser editable desde el panel de administrador
- Los datos de los participantes solo los puede modificar el administrador

## Accepted Requirements

- Página pública donde cada persona pide su número según la tabla publicada
- Registro de datos del participante que quedan guardados
- Pago y envío de comprobante por WhatsApp
- Datos bloqueados para todos excepto el administrador
- Panel de administrador para editar, modificar y restablecer la rifa
- Interfaz limpia en blanco, negro, gris y verde
- Código completo para GitHub

## Verified Commands

- **typecheck**: `pnpm typecheck`
- **fix**: `pnpm fix`
- **build**: `pnpm build`

## Learnings

- Frontend commands from src/frontend/: pnpm typecheck, pnpm fix; backend commands from src/backend/: mops check --fix, mops build; bindings from the project root: pnpm bindgen.
- The raffle domain lives in src/backend/lib/raffle.mo and src/backend/mixins/raffle-api.mo; the participant domain lives in src/backend/lib/participants.mo and src/backend/mixins/participants-api.mo; src/backend/main.mo is the composition root that wires both into the actor.
- resetRaffle must release every number and also clear the participant records through ParticipantsLib.clearAll; the frontend reset mutation invalidates numbers, participants and settings.
- The payment proof uses Storage.ExternalBlob from the object-storage extension, which requires the caffeineai-object-storage dependency in mops.toml.
- The frontend foundation provides src/frontend/src/hooks/useRaffle.ts with the raffle and participant hooks and src/frontend/src/lib/format.ts with the currency and date helpers; pages consume them instead of calling the actor directly.
- A global @media (prefers-reduced-motion: reduce) rule in src/frontend/src/index.css neutralizes the decorative animations and slows the spinners.
