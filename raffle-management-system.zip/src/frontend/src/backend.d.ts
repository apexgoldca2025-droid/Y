import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Cell {
    value: Value;
    name: string;
}
export type Error_ = {
    __kind__: "FrontendOriginsNotConfigured";
    FrontendOriginsNotConfigured: null;
} | {
    __kind__: "MixedSsoSources";
    MixedSsoSources: {
        otherKeys: Array<string>;
        ssoKeys: Array<string>;
    };
} | {
    __kind__: "Stale";
    Stale: {
        ageNs: bigint;
    };
} | {
    __kind__: "MalformedCandid";
    MalformedCandid: null;
} | {
    __kind__: "AmbiguousAttribute";
    AmbiguousAttribute: {
        field: string;
        sources: Array<string>;
    };
} | {
    __kind__: "NoAttributes";
    NoAttributes: null;
} | {
    __kind__: "UnknownNonce";
    UnknownNonce: null;
} | {
    __kind__: "UntrustedSsoSource";
    UntrustedSsoSource: {
        domain: string;
    };
} | {
    __kind__: "MissingField";
    MissingField: string;
} | {
    __kind__: "FrontendOriginMismatch";
    FrontendOriginMismatch: {
        got: string;
        expected: Array<string>;
    };
};
export type NumberId = bigint;
export interface Participant {
    id: ParticipantId;
    paymentStatus: PaymentStatus;
    createdAt: Timestamp;
    fullName: string;
    email: string;
    totalAmount: bigint;
    numbers: Array<bigint>;
    phone: string;
    proof?: ProofBlob;
}
export type ParticipantId = bigint;
export interface ParticipantInput {
    fullName: string;
    email: string;
    phone: string;
}
export interface PaymentDetails {
    cbu: string;
    alias: string;
    amount: bigint;
    accountHolder: string;
}
export type ProofBlob = Uint8Array;
export interface RaffleNumber {
    id: NumberId;
    value: bigint;
    state: NumberState;
}
export interface RaffleSettings {
    title: string;
    drawDate: Timestamp;
    description: string;
    pricePerNumber: bigint;
    prize: string;
    payment: PaymentDetails;
}
export interface Result {
    hasMore: boolean;
    rows: Array<Array<Cell>>;
}
export type Result__1 = {
    __kind__: "ok";
    ok: null;
} | {
    __kind__: "err";
    err: Error_;
};
export type Timestamp = bigint;
export type Value = {
    __kind__: "int";
    int: bigint;
} | {
    __kind__: "nat";
    nat: bigint;
} | {
    __kind__: "float";
    float: number;
} | {
    __kind__: "bool";
    bool: boolean;
} | {
    __kind__: "null";
    null: null;
} | {
    __kind__: "text";
    text: string;
};
export enum NumberState {
    paid = "paid",
    reserved = "reserved",
    available = "available"
}
export enum PaymentStatus {
    proofSubmitted = "proofSubmitted",
    pending = "pending",
    confirmed = "confirmed"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    attachProof(id: ParticipantId, proof: ProofBlob): Promise<void>;
    createNumber(value: bigint): Promise<NumberId>;
    deleteNumber(id: NumberId): Promise<void>;
    deleteParticipant(id: ParticipantId): Promise<void>;
    execute(qJson: string): Promise<Result>;
    getApiDoc(): Promise<string>;
    getCallerUserRole(): Promise<UserRole>;
    getNumberTable(): Promise<Array<RaffleNumber>>;
    getRaffleSettings(): Promise<RaffleSettings>;
    isCallerAdmin(): Promise<boolean>;
    listParticipants(): Promise<Array<Participant>>;
    reserveNumbers(input: ParticipantInput, selected: Array<bigint>): Promise<ParticipantId>;
    resetRaffle(): Promise<void>;
    schema(): Promise<string>;
    setNumberState(id: NumberId, state: NumberState): Promise<void>;
    updateNumber(id: NumberId, value: bigint): Promise<void>;
    updateParticipant(id: ParticipantId, input: ParticipantInput, status: PaymentStatus): Promise<void>;
    updateRaffleSettings(next: RaffleSettings): Promise<void>;
}
