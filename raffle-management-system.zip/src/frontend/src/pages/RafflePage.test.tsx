import { renderWithActor } from "@/__tests__/test-utils";
import type { RaffleNumber, RaffleSettings, backendInterface } from "@/backend";
import { NumberState } from "@/backend";
import { screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import RafflePage from "./RafflePage";

const settings: RaffleSettings = {
  title: "Rifa solidaria 2026",
  description: "Ayudanos a recaudar fondos.",
  pricePerNumber: 1500n,
  drawDate: 1_800_000_000_000_000_000n,
  prize: "Una bicicleta",
  payment: {
    alias: "rifa.solidaria",
    cbu: "0000000000000000000000",
    accountHolder: "María González",
    amount: 1500n,
  },
};

const numbers: RaffleNumber[] = [
  { id: 0n, value: 1n, state: NumberState.available },
  { id: 1n, value: 2n, state: NumberState.available },
  { id: 2n, value: 3n, state: NumberState.reserved },
  { id: 3n, value: 4n, state: NumberState.paid },
];

type RaffleActor = Pick<
  backendInterface,
  "getRaffleSettings" | "getNumberTable" | "reserveNumbers" | "attachProof"
>;

function makeActor(overrides: Partial<RaffleActor> = {}): RaffleActor {
  return {
    getRaffleSettings: vi.fn<backendInterface["getRaffleSettings"]>(async () =>
      structuredClone(settings),
    ),
    getNumberTable: vi.fn<backendInterface["getNumberTable"]>(async () =>
      structuredClone(numbers),
    ),
    reserveNumbers: vi.fn<backendInterface["reserveNumbers"]>(async () => 7n),
    attachProof: vi.fn<backendInterface["attachProof"]>(async () => undefined),
    ...overrides,
  };
}

describe("RafflePage", () => {
  it("renders the public raffle page with settings and the number table", async () => {
    renderWithActor(<RafflePage />, makeActor());

    expect(
      await screen.findByRole("heading", { name: "Rifa solidaria 2026" }),
    ).toBeInTheDocument();
    expect(screen.getByText("Una bicicleta")).toBeInTheDocument();

    const grid = await screen.findByTestId("raffle.number_grid");
    expect(
      within(grid).getByRole("button", { name: /Número 01/ }),
    ).toBeEnabled();
    expect(
      within(grid).getByRole("button", { name: /Número 02/ }),
    ).toBeEnabled();
  });

  it("disables reserved and paid numbers so they cannot be selected", async () => {
    renderWithActor(<RafflePage />, makeActor());

    const grid = await screen.findByTestId("raffle.number_grid");
    expect(
      within(grid).getByRole("button", { name: /Número 03 — Reservado/ }),
    ).toBeDisabled();
    expect(
      within(grid).getByRole("button", { name: /Número 04 — Pagado/ }),
    ).toBeDisabled();
  });

  it("reserves selected numbers and shows the confirmation with total and WhatsApp link", async () => {
    const user = userEvent.setup();
    const reserveNumbers = vi.fn<backendInterface["reserveNumbers"]>(
      async () => 7n,
    );
    renderWithActor(<RafflePage />, makeActor({ reserveNumbers }));

    const grid = await screen.findByTestId("raffle.number_grid");
    await user.click(within(grid).getByRole("button", { name: /Número 01/ }));
    await user.click(within(grid).getByRole("button", { name: /Número 02/ }));

    await user.type(
      screen.getByTestId("raffle.fullname_input"),
      "María González",
    );
    await user.type(screen.getByTestId("raffle.phone_input"), "1155555555");
    await user.type(
      screen.getByTestId("raffle.email_input"),
      "maria@correo.com",
    );
    await user.click(screen.getByTestId("raffle.reserve_button"));

    await waitFor(() =>
      expect(reserveNumbers).toHaveBeenCalledWith(
        {
          fullName: "María González",
          phone: "1155555555",
          email: "maria@correo.com",
        },
        [1n, 2n],
      ),
    );

    const panel = await screen.findByTestId("raffle.confirmation_panel");
    expect(within(panel).getByText("¡Números reservados!")).toBeInTheDocument();
    // 2 numbers × 1500 = 3000, formatted as ARS currency.
    expect(within(panel).getAllByText(/3\.000/).length).toBeGreaterThan(0);

    const whatsapp = within(panel).getByTestId("raffle.whatsapp_button");
    expect(whatsapp).toHaveAttribute("href", expect.stringContaining("wa.me"));
    const href = whatsapp.getAttribute("href") ?? "";
    expect(decodeURIComponent(href)).toContain("Números: 01, 02");
  });

  it("attaches a payment proof image to the reservation", async () => {
    const user = userEvent.setup();
    const attachProof = vi.fn<backendInterface["attachProof"]>(
      async () => undefined,
    );
    renderWithActor(<RafflePage />, makeActor({ attachProof }));

    const grid = await screen.findByTestId("raffle.number_grid");
    await user.click(within(grid).getByRole("button", { name: /Número 01/ }));
    await user.type(
      screen.getByTestId("raffle.fullname_input"),
      "María González",
    );
    await user.type(screen.getByTestId("raffle.phone_input"), "1155555555");
    await user.type(
      screen.getByTestId("raffle.email_input"),
      "maria@correo.com",
    );
    await user.click(screen.getByTestId("raffle.reserve_button"));

    await screen.findByTestId("raffle.confirmation_panel");

    // jsdom's File lacks arrayBuffer(); supply the browser method the app uses.
    const file = new File([new Uint8Array([1, 2, 3])], "proof.png", {
      type: "image/png",
    });
    Object.defineProperty(file, "arrayBuffer", {
      value: async () => new Uint8Array([1, 2, 3]).buffer,
    });
    await user.upload(screen.getByTestId("raffle.proof_input"), file);

    await waitFor(() => expect(attachProof).toHaveBeenCalledTimes(1));
    expect(attachProof.mock.calls[0][0]).toBe(7n);
    expect(
      await screen.findByTestId("raffle.proof_success_state"),
    ).toBeInTheDocument();
  });

  it("shows a settings error state instead of a blank page when the raffle is not configured", async () => {
    const getRaffleSettings = vi.fn<backendInterface["getRaffleSettings"]>(
      async () => {
        throw new Error("not configured");
      },
    );
    renderWithActor(<RafflePage />, makeActor({ getRaffleSettings }));

    expect(
      await screen.findByTestId("raffle.settings_error_state"),
    ).toBeInTheDocument();
  });
});
