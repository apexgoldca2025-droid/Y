import { NumbersManager } from "@/components/admin/NumbersManager";
import { ParticipantsTable } from "@/components/admin/ParticipantsTable";
import { RaffleSettingsForm } from "@/components/admin/RaffleSettingsForm";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";
import { useResetRaffle } from "@/hooks/useRaffle";
import { Loader2, RotateCcw, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

export default function AdminPage() {
  const resetRaffle = useResetRaffle();

  const handleReset = () => {
    resetRaffle.mutate(undefined, {
      onSuccess: () =>
        toast.success(
          "Rifa restablecida: números liberados y participantes borrados",
        ),
      onError: () =>
        toast.error("No se pudo restablecer la rifa. Verificá tus permisos."),
    });
  };

  return (
    <div
      data-ocid="admin.page"
      className="mx-auto w-full max-w-6xl animate-fade-in px-4 py-12 sm:px-6 md:py-16"
    >
      <Toaster position="top-right" richColors closeButton />
      <header className="flex flex-col gap-6 border-b border-border pb-8 md:flex-row md:items-end md:justify-between">
        <div className="space-y-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-primary">
            <ShieldCheck className="size-3.5" aria-hidden="true" />
            Administración
          </span>
          <h1 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Panel de administración
          </h1>
          <p className="max-w-2xl text-muted-foreground">
            Gestioná la configuración, los números y los participantes de la
            rifa. Los cambios se reflejan en la página pública.
          </p>
        </div>

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              type="button"
              variant="outline"
              data-ocid="admin.reset.open_modal_button"
              className="w-fit rounded-lg text-destructive hover:bg-destructive/10 hover:text-destructive"
            >
              <RotateCcw className="size-4" aria-hidden="true" />
              Restablecer rifa
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent data-ocid="admin.reset.dialog">
            <AlertDialogHeader>
              <AlertDialogTitle className="font-display">
                ¿Restablecer toda la rifa?
              </AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción libera todos los números (vuelven a estar
                disponibles) y borra por completo los registros de
                participantes, incluidos sus datos y comprobantes de pago. No se
                puede deshacer.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel
                data-ocid="admin.reset.cancel_button"
                className="rounded-lg"
              >
                Cancelar
              </AlertDialogCancel>
              <AlertDialogAction
                data-ocid="admin.reset.confirm_button"
                disabled={resetRaffle.isPending}
                onClick={handleReset}
                className="rounded-lg bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {resetRaffle.isPending ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                ) : (
                  <RotateCcw className="size-4" aria-hidden="true" />
                )}
                Sí, restablecer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </header>

      <div className="mt-10 space-y-10">
        <section
          aria-labelledby="admin-settings-heading"
          data-ocid="admin.settings.section"
          className="space-y-4"
        >
          <h2
            id="admin-settings-heading"
            className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground"
          >
            Configuración
          </h2>
          <RaffleSettingsForm />
        </section>

        <section
          aria-labelledby="admin-numbers-heading"
          data-ocid="admin.numbers.section"
          className="space-y-4"
        >
          <h2
            id="admin-numbers-heading"
            className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground"
          >
            Números
          </h2>
          <NumbersManager />
        </section>

        <section
          aria-labelledby="admin-participants-heading"
          data-ocid="admin.participants.section"
          className="space-y-4"
        >
          <h2
            id="admin-participants-heading"
            className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground"
          >
            Participantes
          </h2>
          <ParticipantsTable />
        </section>
      </div>
    </div>
  );
}
