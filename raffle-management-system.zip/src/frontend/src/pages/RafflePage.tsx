import type { ParticipantInput, RaffleNumber } from "@/backend";
import { NumberState } from "@/backend";
import { ConfirmationPanel } from "@/components/ConfirmationPanel";
import { NumberGrid } from "@/components/NumberGrid";
import { RegistrationForm } from "@/components/RegistrationForm";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAttachProof,
  useNumberTable,
  useRaffleSettings,
  useReserveNumbers,
} from "@/hooks/useRaffle";
import { formatCurrency, formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";
import {
  AlertTriangle,
  CalendarDays,
  Gift,
  RefreshCw,
  Ticket,
  Wallet,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

interface ReservationResult {
  id: bigint;
  fullName: string;
  phone: string;
  email: string;
  numbers: bigint[];
  totalAmount: bigint;
}

const REFRESH_INTERVAL_MS = 15_000;

export default function RafflePage() {
  const settingsQuery = useRaffleSettings();
  const numbersQuery = useNumberTable();
  const reserveMutation = useReserveNumbers();
  const attachProofMutation = useAttachProof();

  const [selected, setSelected] = useState<bigint[]>([]);
  const [reservation, setReservation] = useState<ReservationResult | null>(
    null,
  );
  const [proofAttached, setProofAttached] = useState(false);
  const [proofError, setProofError] = useState<string | undefined>(undefined);

  const settings = settingsQuery.data;
  const numbers = numbersQuery.data ?? [];

  const availableCount = useMemo(
    () =>
      numbers.filter((number) => number.state === NumberState.available).length,
    [numbers],
  );

  const selectedTotal = settings
    ? settings.pricePerNumber * BigInt(selected.length)
    : 0n;

  const { refetch: refetchNumbers } = numbersQuery;

  // Keep the table fresh so reservations made by other visitors appear.
  useEffect(() => {
    const interval = window.setInterval(() => {
      void refetchNumbers();
    }, REFRESH_INTERVAL_MS);
    return () => window.clearInterval(interval);
  }, [refetchNumbers]);

  function toggleNumber(value: bigint) {
    setSelected((current) => {
      const exists = current.some((item) => item === value);
      if (exists) return current.filter((item) => item !== value);
      return [...current, value];
    });
  }

  function handleReserve(input: ParticipantInput) {
    reserveMutation.mutate(
      { input, selected },
      {
        onSuccess: (id) => {
          setReservation({
            id,
            fullName: input.fullName,
            phone: input.phone,
            email: input.email,
            numbers: [...selected],
            totalAmount: selectedTotal,
          });
          setSelected([]);
          setProofAttached(false);
          setProofError(undefined);
        },
      },
    );
  }

  function handleAttachProof(file: File) {
    if (!reservation) return;
    setProofError(undefined);
    if (!file.type.startsWith("image/")) {
      setProofError("El comprobante debe ser una imagen (JPG o PNG).");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setProofError("La imagen no puede superar los 5 MB.");
      return;
    }
    void file.arrayBuffer().then((buffer) => {
      attachProofMutation.mutate(
        { id: reservation.id, proof: new Uint8Array(buffer) },
        {
          onSuccess: () => setProofAttached(true),
          onError: () =>
            setProofError(
              "No pudimos guardar el comprobante. Intentá nuevamente.",
            ),
        },
      );
    });
  }

  if (settingsQuery.isLoading) {
    return <RaffleSkeleton />;
  }

  if (settingsQuery.isError || !settings) {
    return (
      <section
        data-ocid="raffle.settings_error_state"
        className="mx-auto flex w-full max-w-lg flex-col items-center gap-4 px-4 py-24 text-center sm:px-6"
      >
        <span className="flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
          <AlertTriangle className="size-7" aria-hidden="true" />
        </span>
        <h1 className="font-display text-2xl font-bold text-foreground">
          La rifa todavía no está configurada
        </h1>
        <p className="text-muted-foreground">
          El organizador aún no publicó los datos de la rifa. Volvé a intentarlo
          en unos minutos.
        </p>
        <Button
          type="button"
          variant="outline"
          data-ocid="raffle.settings_retry_button"
          onClick={() => void settingsQuery.refetch()}
          className="rounded-lg border-border transition-smooth hover:bg-muted"
        >
          <RefreshCw className="size-4" aria-hidden="true" />
          Reintentar
        </Button>
      </section>
    );
  }

  return (
    <div data-ocid="raffle.page" className="pb-16 md:pb-24">
      <section className="border-b border-border bg-gradient-subtle">
        <div className="mx-auto w-full max-w-6xl px-4 py-12 sm:px-6 md:py-16">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl animate-fade-in">
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-primary">
                <Ticket className="size-3.5" aria-hidden="true" />
                Rifa solidaria
              </span>
              <h1 className="mt-4 font-display text-4xl font-bold tracking-tight text-foreground md:text-5xl">
                {settings.title}
              </h1>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                {settings.description}
              </p>
            </div>

            <dl className="grid w-full grid-cols-1 gap-3 sm:grid-cols-3 md:w-auto md:min-w-[22rem]">
              <HeroStat
                icon={<Wallet className="size-4" aria-hidden="true" />}
                label="Precio por número"
                value={formatCurrency(settings.pricePerNumber)}
              />
              <HeroStat
                icon={<CalendarDays className="size-4" aria-hidden="true" />}
                label="Fecha del sorteo"
                value={formatDate(settings.drawDate)}
              />
              <HeroStat
                icon={<Gift className="size-4" aria-hidden="true" />}
                label="Premio"
                value={settings.prize}
              />
            </dl>
          </div>
        </div>
      </section>

      <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 sm:px-6 md:py-16 lg:grid-cols-[1.6fr_1fr]">
        <section aria-label="Tabla de números" className="min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground">
                Elegí tus números
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {availableCount}{" "}
                {availableCount === 1
                  ? "número disponible"
                  : "números disponibles"}
                {numbersQuery.isFetching ? " · actualizando…" : ""}
              </p>
            </div>
            <Legend />
          </div>

          <div className="mt-6 rounded-xl border border-border bg-card p-4 shadow-subtle sm:p-6">
            {numbersQuery.isLoading ? (
              <NumberGridSkeleton />
            ) : numbers.length === 0 ? (
              <p
                data-ocid="raffle.numbers_empty_state"
                className="py-12 text-center text-muted-foreground"
              >
                Todavía no hay números publicados para esta rifa.
              </p>
            ) : (
              <NumberGrid
                numbers={numbers}
                selected={selected}
                onToggle={toggleNumber}
                disabled={Boolean(reservation)}
              />
            )}
          </div>

          {numbersQuery.isError ? (
            <p
              data-ocid="raffle.numbers_error_state"
              className="mt-4 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive"
            >
              No pudimos cargar la tabla de números. Se reintentará
              automáticamente.
            </p>
          ) : null}
        </section>

        <aside aria-label="Reserva" className="min-w-0">
          <div className="sticky top-24 rounded-xl border border-border bg-card p-6 shadow-subtle">
            {reservation ? (
              <ConfirmationPanel
                fullName={reservation.fullName}
                phone={reservation.phone}
                email={reservation.email}
                numbers={reservation.numbers}
                totalAmount={reservation.totalAmount}
                payment={settings.payment}
                proofAttached={proofAttached}
                isUploading={attachProofMutation.isPending}
                uploadError={proofError}
                onAttachProof={handleAttachProof}
              />
            ) : selected.length === 0 ? (
              <div
                data-ocid="raffle.selection_empty_state"
                className="flex flex-col items-center gap-3 py-8 text-center"
              >
                <span className="flex size-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Ticket className="size-6" aria-hidden="true" />
                </span>
                <p className="font-display font-semibold text-foreground">
                  Ningún número seleccionado
                </p>
                <p className="text-sm text-muted-foreground">
                  Tocá los números disponibles en la tabla para reservarlos.
                </p>
              </div>
            ) : (
              <RegistrationForm
                selected={selected}
                pricePerNumber={settings.pricePerNumber}
                isPending={reserveMutation.isPending}
                errorMessage={
                  reserveMutation.isError
                    ? "No pudimos reservar los números. Puede que alguno ya no esté disponible; actualizá la tabla e intentá de nuevo."
                    : undefined
                }
                onSubmit={handleReserve}
              />
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}

function HeroStat({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-subtle">
      <dt className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        <span className="text-primary">{icon}</span>
        {label}
      </dt>
      <dd className="mt-2 font-display text-lg font-bold text-foreground">
        {value}
      </dd>
    </div>
  );
}

function Legend() {
  const items = [
    { label: "Disponible", className: "border-border bg-card" },
    { label: "Reservado", className: "border-transparent bg-muted" },
    { label: "Pagado", className: "border-transparent bg-primary" },
  ];
  return (
    <ul className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
      {items.map((item) => (
        <li key={item.label} className="flex items-center gap-1.5">
          <span
            className={cn("size-3 rounded-sm border", item.className)}
            aria-hidden="true"
          />
          {item.label}
        </li>
      ))}
    </ul>
  );
}

function NumberGridSkeleton() {
  const ids = Array.from(
    { length: 24 },
    (_, index) => `number-skeleton-${index}`,
  );
  return (
    <div className="grid grid-cols-5 gap-2 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12">
      {ids.map((id) => (
        <Skeleton key={id} className="aspect-square rounded-md" />
      ))}
    </div>
  );
}

function RaffleSkeleton() {
  return (
    <div data-ocid="raffle.loading_state" className="pb-16 md:pb-24">
      <section className="border-b border-border bg-gradient-subtle">
        <div className="mx-auto w-full max-w-6xl px-4 py-12 sm:px-6 md:py-16">
          <Skeleton className="h-6 w-32 rounded-full" />
          <Skeleton className="mt-4 h-12 w-3/4 max-w-xl" />
          <Skeleton className="mt-4 h-5 w-full max-w-2xl" />
          <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Skeleton className="h-20 rounded-xl" />
            <Skeleton className="h-20 rounded-xl" />
            <Skeleton className="h-20 rounded-xl" />
          </div>
        </div>
      </section>
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 sm:px-6 md:py-16 lg:grid-cols-[1.6fr_1fr]">
        <Skeleton className="h-96 rounded-xl" />
        <Skeleton className="h-72 rounded-xl" />
      </div>
    </div>
  );
}
