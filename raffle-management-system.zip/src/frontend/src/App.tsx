import { RequireSignIn, SignInButton } from "@/components/InternetIdentity";
import { Layout } from "@/components/Layout";
import { useIsAdmin } from "@/hooks/useRaffle";
import AdminPage from "@/pages/AdminPage";
import RafflePage from "@/pages/RafflePage";
import {
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";

function RootLayout() {
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
}

/** Signed-in but not an administrator: explain the boundary, keep sign-out reachable. */
function AdminAccessDenied() {
  return (
    <section
      aria-label="Acceso restringido"
      data-ocid="admin.access_denied_state"
      className="mx-auto flex w-full max-w-lg flex-col items-center gap-4 px-4 py-24 text-center sm:px-6"
    >
      <span className="flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
        <ShieldAlert className="size-7" aria-hidden="true" />
      </span>
      <h1 className="font-display text-2xl font-bold text-foreground">
        No tenés acceso al panel
      </h1>
      <p className="text-muted-foreground">
        Tu cuenta no tiene permisos de administrador. Si creés que es un error,
        contactá al organizador de la rifa.
      </p>
      <SignInButton className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground transition-smooth hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
    </section>
  );
}

/** Gate the admin panel: sign-in first, then administrator role. */
function RequireAdmin() {
  return (
    <RequireSignIn
      fallback={
        <section
          aria-label="Iniciar sesión"
          data-ocid="admin.sign_in_state"
          className="mx-auto flex w-full max-w-lg flex-col items-center gap-4 px-4 py-24 text-center sm:px-6"
        >
          <h1 className="font-display text-2xl font-bold text-foreground">
            Iniciá sesión para administrar
          </h1>
          <p className="text-muted-foreground">
            El panel de administración es privado. Ingresá con tu Internet
            Identity para continuar.
          </p>
          <SignInButton className="rounded-lg bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-smooth hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
        </section>
      }
    >
      <AdminGate />
    </RequireSignIn>
  );
}

function AdminGate() {
  const { data: isAdmin, isLoading } = useIsAdmin();
  if (isLoading) {
    return (
      <output
        data-ocid="admin.loading_state"
        className="mx-auto block w-full max-w-lg px-4 py-24 text-center text-muted-foreground sm:px-6"
      >
        Verificando permisos…
      </output>
    );
  }
  if (!isAdmin) {
    return <AdminAccessDenied />;
  }
  return <AdminPage />;
}

const rootRoute = createRootRoute({ component: RootLayout });

const raffleRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: RafflePage,
});

const adminRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin",
  component: RequireAdmin,
});

const routeTree = rootRoute.addChildren([raffleRoute, adminRoute]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
