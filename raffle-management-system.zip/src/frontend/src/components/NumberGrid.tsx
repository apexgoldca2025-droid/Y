import type { RaffleNumber } from "@/backend";
import { NumberState } from "@/backend";
import { formatNumber } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Check, Lock } from "lucide-react";

const stateStyles: Record<NumberState, string> = {
  [NumberState.available]:
    "border-border bg-card text-foreground hover:border-primary hover:text-primary hover:shadow-elevated",
  [NumberState.reserved]:
    "border-transparent bg-muted text-muted-foreground cursor-not-allowed",
  [NumberState.paid]:
    "border-transparent bg-primary text-primary-foreground cursor-not-allowed",
};

const stateLabels: Record<NumberState, string> = {
  [NumberState.available]: "Disponible",
  [NumberState.reserved]: "Reservado",
  [NumberState.paid]: "Pagado",
};

export interface NumberGridProps {
  numbers: RaffleNumber[];
  selected: bigint[];
  onToggle: (value: bigint) => void;
  disabled?: boolean;
}

export function NumberGrid({
  numbers,
  selected,
  onToggle,
  disabled = false,
}: NumberGridProps) {
  const selectedSet = new Set(selected.map((value) => value.toString()));

  return (
    <div
      data-ocid="raffle.number_grid"
      className="grid grid-cols-5 gap-2 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12"
    >
      {numbers.map((number) => {
        const key = number.value.toString();
        const isSelected = selectedSet.has(key);
        const isAvailable = number.state === NumberState.available;
        const isInteractive = isAvailable && !disabled;

        return (
          <button
            key={key}
            type="button"
            data-ocid={`raffle.number.${key}`}
            aria-pressed={isSelected}
            aria-label={`Número ${formatNumber(number.value)} — ${stateLabels[number.state]}`}
            disabled={!isInteractive}
            onClick={() => onToggle(number.value)}
            className={cn(
              "relative flex aspect-square items-center justify-center rounded-md border text-sm font-semibold transition-smooth ticket-number focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
              stateStyles[number.state],
              isSelected &&
                "border-primary bg-primary text-primary-foreground shadow-elevated",
            )}
          >
            {formatNumber(number.value)}
            {number.state === NumberState.paid ? (
              <Check
                className="absolute right-1 top-1 size-3 opacity-80"
                aria-hidden="true"
              />
            ) : null}
            {number.state === NumberState.reserved ? (
              <Lock
                className="absolute right-1 top-1 size-3 opacity-70"
                aria-hidden="true"
              />
            ) : null}
          </button>
        );
      })}
    </div>
  );
}
