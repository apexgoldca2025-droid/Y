import type { PaymentDetails } from "@/backend";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatNumber } from "@/lib/format";
import { cn } from "@/lib/utils";
import {
  CheckCircle2,
  Copy,
  ImagePlus,
  Loader2,
  MessageCircle,
} from "lucide-react";
import { type ChangeEvent, useRef, useState } from "react";

export interface ConfirmationPanelProps {
  fullName: string;
  phone: string;
  email: string;
  numbers: bigint[];
  totalAmount: bigint;
  payment: PaymentDetails;
  proofAttached: boolean;
  isUploading: boolean;
  uploadError?: string;
  onAttachProof: (file: File) => void;
}

const MAX_PROOF_BYTES = 5 * 1024 * 1024;

function buildWhatsAppMessage({
  fullName,
  phone,
  email,
  numbers,
  totalAmount,
  payment,
}: {
  fullName: string;
  phone: string;
  email: string;
  numbers: bigint[];
  totalAmount: bigint;
  payment: PaymentDetails;
}): string {
  const list = numbers.map((value) => formatNumber(value)).join(", ");
  return [
    "¡Hola! Reservé números en la rifa y quiero enviar mi comprobante de pago.",
    "",
    `Nombre: ${fullName}`,
    `Teléfono: ${phone}`,
    `Correo: ${email}`,
    `Números: ${list}`,
    `Total a pagar: ${formatCurrency(totalAmount)}`,
    "",
    `Alias: ${payment.alias}`,
    `CBU: ${payment.cbu}`,
    `Titular: ${payment.accountHolder}`,
  ].join("\n");
}

export function ConfirmationPanel({
  fullName,
  phone,
  email,
  numbers,
  totalAmount,
  payment,
  proofAttached,
  isUploading,
  uploadError,
  onAttachProof,
}: ConfirmationPanelProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [copied, setCopied] = useState<"alias" | "cbu" | null>(null);

  const whatsappHref = `https://wa.me/?text=${encodeURIComponent(
    buildWhatsAppMessage({
      fullName,
      phone,
      email,
      numbers,
      totalAmount,
      payment,
    }),
  )}`;

  async function copyValue(value: string, kind: "alias" | "cbu") {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(kind);
      window.setTimeout(() => setCopied(null), 2000);
    } catch {
      setCopied(null);
    }
  }

  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_PROOF_BYTES) {
      onAttachProof(file);
      event.target.value = "";
      return;
    }
    onAttachProof(file);
    event.target.value = "";
  }

  return (
    <div
      data-ocid="raffle.confirmation_panel"
      className="space-y-6 animate-fade-in"
    >
      <div className="flex items-start gap-3 rounded-lg border border-primary/30 bg-primary/5 p-4">
        <CheckCircle2
          className="mt-0.5 size-5 shrink-0 text-primary"
          aria-hidden="true"
        />
        <div>
          <p className="font-display font-semibold text-foreground">
            ¡Números reservados!
          </p>
          <p className="text-sm text-muted-foreground">
            Guardamos tus datos. Completá el pago y enviá el comprobante para
            confirmar tu participación.
          </p>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Tus números
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          {numbers.map((value) => (
            <span
              key={value.toString()}
              className="inline-flex min-w-10 items-center justify-center rounded-md bg-primary px-2.5 py-1.5 font-mono text-sm font-semibold text-primary-foreground"
            >
              {formatNumber(value)}
            </span>
          ))}
        </div>
        <div className="mt-4 flex items-baseline justify-between border-t border-border pt-3">
          <span className="text-sm text-muted-foreground">Total a pagar</span>
          <span className="font-display text-xl font-bold text-foreground">
            {formatCurrency(totalAmount)}
          </span>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-card p-4">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Datos de pago
        </p>
        <dl className="mt-3 space-y-3">
          <PaymentRow
            label="Alias"
            value={payment.alias}
            copied={copied === "alias"}
            onCopy={() => copyValue(payment.alias, "alias")}
          />
          <PaymentRow
            label="CBU"
            value={payment.cbu}
            copied={copied === "cbu"}
            onCopy={() => copyValue(payment.cbu, "cbu")}
          />
          <div className="flex items-center justify-between gap-3">
            <dt className="text-sm text-muted-foreground">Titular</dt>
            <dd className="text-right text-sm font-medium text-foreground">
              {payment.accountHolder}
            </dd>
          </div>
          <div className="flex items-center justify-between gap-3">
            <dt className="text-sm text-muted-foreground">Monto</dt>
            <dd className="text-right font-mono text-sm font-semibold text-foreground">
              {formatCurrency(totalAmount)}
            </dd>
          </div>
        </dl>
      </div>

      <a
        href={whatsappHref}
        target="_blank"
        rel="noreferrer"
        data-ocid="raffle.whatsapp_button"
        className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-smooth hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
      >
        <MessageCircle className="size-4" aria-hidden="true" />
        Enviar comprobante por WhatsApp
      </a>

      <div className="rounded-lg border border-dashed border-border bg-muted/30 p-4">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Comprobante de pago
        </p>
        {proofAttached ? (
          <p
            data-ocid="raffle.proof_success_state"
            className="mt-2 flex items-center gap-2 text-sm font-medium text-primary"
          >
            <CheckCircle2 className="size-4" aria-hidden="true" />
            Comprobante adjuntado correctamente.
          </p>
        ) : (
          <p className="mt-2 text-sm text-muted-foreground">
            Adjuntá la imagen de tu transferencia para que el organizador la
            verifique.
          </p>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="sr-only"
          data-ocid="raffle.proof_input"
          onChange={handleFileChange}
        />
        <Button
          type="button"
          variant="outline"
          data-ocid="raffle.proof_upload_button"
          disabled={isUploading}
          onClick={() => fileInputRef.current?.click()}
          className="mt-3 w-full rounded-lg border-border transition-smooth hover:bg-muted"
        >
          {isUploading ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Subiendo…
            </>
          ) : (
            <>
              <ImagePlus className="size-4" aria-hidden="true" />
              {proofAttached
                ? "Reemplazar comprobante"
                : "Adjuntar comprobante"}
            </>
          )}
        </Button>

        {uploadError ? (
          <p
            data-ocid="raffle.proof_error_state"
            className="mt-2 text-sm text-destructive"
          >
            {uploadError}
          </p>
        ) : null}
      </div>
    </div>
  );
}

function PaymentRow({
  label,
  value,
  copied,
  onCopy,
}: {
  label: string;
  value: string;
  copied: boolean;
  onCopy: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="flex min-w-0 items-center gap-2">
        <span className="truncate font-mono text-sm font-medium text-foreground">
          {value}
        </span>
        <button
          type="button"
          onClick={onCopy}
          aria-label={`Copiar ${label}`}
          className={cn(
            "inline-flex size-7 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground transition-smooth hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            copied && "border-primary text-primary",
          )}
        >
          <Copy className="size-3.5" aria-hidden="true" />
        </button>
      </dd>
    </div>
  );
}
