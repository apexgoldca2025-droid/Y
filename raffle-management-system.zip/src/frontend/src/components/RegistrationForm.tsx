import type { ParticipantInput } from "@/backend";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatCurrency, formatNumber } from "@/lib/format";
import { Loader2 } from "lucide-react";
import { type FormEvent, useState } from "react";

export interface RegistrationFormProps {
  selected: bigint[];
  pricePerNumber: bigint;
  isPending: boolean;
  errorMessage?: string;
  onSubmit: (input: ParticipantInput) => void;
}

interface FieldErrors {
  fullName?: string;
  phone?: string;
  email?: string;
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(input: ParticipantInput): FieldErrors {
  const errors: FieldErrors = {};
  if (input.fullName.trim().length < 3) {
    errors.fullName = "Ingresá tu nombre y apellido completos.";
  }
  const digits = input.phone.replace(/\D/g, "");
  if (digits.length < 8) {
    errors.phone = "Ingresá un teléfono válido (al menos 8 dígitos).";
  }
  if (!EMAIL_PATTERN.test(input.email.trim())) {
    errors.email = "Ingresá un correo electrónico válido.";
  }
  return errors;
}

export function RegistrationForm({
  selected,
  pricePerNumber,
  isPending,
  errorMessage,
  onSubmit,
}: RegistrationFormProps) {
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});

  const total = pricePerNumber * BigInt(selected.length);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const input: ParticipantInput = {
      fullName: fullName.trim(),
      phone: phone.trim(),
      email: email.trim(),
    };
    const nextErrors = validate(input);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    onSubmit(input);
  }

  return (
    <form
      data-ocid="raffle.registration_form"
      onSubmit={handleSubmit}
      noValidate
      className="space-y-5"
    >
      <div className="rounded-lg border border-border bg-muted/40 p-4">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Números elegidos
        </p>
        <p className="mt-1 font-mono text-lg font-semibold text-foreground">
          {selected.map((value) => formatNumber(value)).join(" · ")}
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          {selected.length} {selected.length === 1 ? "número" : "números"} ·
          Total{" "}
          <span className="font-semibold text-foreground">
            {formatCurrency(total)}
          </span>
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="participant-fullname">Nombre y apellido</Label>
        <Input
          id="participant-fullname"
          data-ocid="raffle.fullname_input"
          value={fullName}
          onChange={(event) => setFullName(event.target.value)}
          placeholder="María González"
          autoComplete="name"
          aria-invalid={Boolean(errors.fullName)}
          aria-describedby={errors.fullName ? "fullname-error" : undefined}
        />
        {errors.fullName ? (
          <p
            id="fullname-error"
            data-ocid="raffle.fullname_error"
            className="text-sm text-destructive"
          >
            {errors.fullName}
          </p>
        ) : null}
      </div>

      <div className="space-y-2">
        <Label htmlFor="participant-phone">Teléfono</Label>
        <Input
          id="participant-phone"
          data-ocid="raffle.phone_input"
          type="tel"
          value={phone}
          onChange={(event) => setPhone(event.target.value)}
          placeholder="+54 9 11 5555 5555"
          autoComplete="tel"
          aria-invalid={Boolean(errors.phone)}
          aria-describedby={errors.phone ? "phone-error" : undefined}
        />
        {errors.phone ? (
          <p
            id="phone-error"
            data-ocid="raffle.phone_error"
            className="text-sm text-destructive"
          >
            {errors.phone}
          </p>
        ) : null}
      </div>

      <div className="space-y-2">
        <Label htmlFor="participant-email">Correo electrónico</Label>
        <Input
          id="participant-email"
          data-ocid="raffle.email_input"
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="maria@correo.com"
          autoComplete="email"
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? "email-error" : undefined}
        />
        {errors.email ? (
          <p
            id="email-error"
            data-ocid="raffle.email_error"
            className="text-sm text-destructive"
          >
            {errors.email}
          </p>
        ) : null}
      </div>

      {errorMessage ? (
        <p
          data-ocid="raffle.registration_error_state"
          className="rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive"
        >
          {errorMessage}
        </p>
      ) : null}

      <Button
        type="submit"
        data-ocid="raffle.reserve_button"
        disabled={isPending || selected.length === 0}
        className="w-full rounded-lg bg-primary text-primary-foreground transition-smooth hover:brightness-110"
      >
        {isPending ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Reservando…
          </>
        ) : (
          "Reservar mis números"
        )}
      </Button>
    </form>
  );
}
