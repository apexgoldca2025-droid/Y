import { NumberState, type RaffleNumber } from "@/backend";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  useCreateNumber,
  useDeleteNumber,
  useNumberTable,
  useSetNumberState,
  useUpdateNumber,
} from "@/hooks/useRaffle";
import { formatNumber } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { type FormEvent, useState } from "react";
import { toast } from "sonner";

const STATE_LABELS: Record<NumberState, string> = {
  [NumberState.available]: "Disponible",
  [NumberState.reserved]: "Reservado",
  [NumberState.paid]: "Pagado",
};

const STATE_BADGE: Record<NumberState, string> = {
  [NumberState.available]: "border-border bg-background text-muted-foreground",
  [NumberState.reserved]: "border-transparent bg-muted text-foreground",
  [NumberState.paid]: "border-transparent bg-primary text-primary-foreground",
};

function parseValue(value: string): bigint | null {
  const trimmed = value.trim();
  if (!/^\d+$/.test(trimmed)) return null;
  return BigInt(trimmed);
}

export function NumbersManager() {
  const { data: numbers, isLoading } = useNumberTable();
  const createNumber = useCreateNumber();
  const updateNumber = useUpdateNumber();
  const deleteNumber = useDeleteNumber();
  const setNumberState = useSetNumberState();

  const [newValue, setNewValue] = useState("");
  const [createError, setCreateError] = useState<string | null>(null);

  const [editing, setEditing] = useState<RaffleNumber | null>(null);
  const [editValue, setEditValue] = useState("");
  const [editError, setEditError] = useState<string | null>(null);

  const [deleting, setDeleting] = useState<RaffleNumber | null>(null);

  const handleCreate = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setCreateError(null);
    const value = parseValue(newValue);
    if (value === null) {
      setCreateError("Ingresá un número entero válido.");
      return;
    }
    createNumber.mutate(value, {
      onSuccess: () => {
        setNewValue("");
        toast.success(`Número ${formatNumber(value)} creado`);
      },
      onError: () =>
        setCreateError(
          "No se pudo crear el número. Verificá tus permisos e intentá de nuevo.",
        ),
    });
  };

  const openEdit = (number: RaffleNumber) => {
    setEditing(number);
    setEditValue(String(number.value));
    setEditError(null);
  };

  const handleEditSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editing) return;
    setEditError(null);
    const value = parseValue(editValue);
    if (value === null) {
      setEditError("Ingresá un número entero válido.");
      return;
    }
    updateNumber.mutate(
      { id: editing.id, value },
      {
        onSuccess: () => {
          setEditing(null);
          toast.success("Número actualizado");
        },
        onError: () =>
          setEditError(
            "No se pudo actualizar el número. Puede que ya no exista.",
          ),
      },
    );
  };

  const handleStateChange = (number: RaffleNumber, state: NumberState) => {
    setNumberState.mutate(
      { id: number.id, state },
      {
        onSuccess: () =>
          toast.success(
            `Número ${formatNumber(number.value)}: ${STATE_LABELS[state].toLowerCase()}`,
          ),
        onError: () => toast.error("No se pudo cambiar el estado del número."),
      },
    );
  };

  const handleDelete = () => {
    if (!deleting) return;
    const target = deleting;
    deleteNumber.mutate(target.id, {
      onSuccess: () => {
        setDeleting(null);
        toast.success(`Número ${formatNumber(target.value)} eliminado`);
      },
      onError: () => toast.error("No se pudo eliminar el número."),
    });
  };

  return (
    <Card
      data-ocid="admin.numbers.card"
      className="rounded-xl border shadow-subtle"
    >
      <CardHeader className="border-b">
        <CardTitle className="font-display text-xl">Tabla de números</CardTitle>
        <CardDescription>
          Creá, editá y eliminá números, y cambiá su estado entre disponible,
          reservado y pagado.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form
          onSubmit={handleCreate}
          className="flex flex-col gap-3 rounded-lg border border-border bg-muted/40 p-4 sm:flex-row sm:items-end"
        >
          <div className="flex-1 space-y-2">
            <Label htmlFor="new-number">Nuevo número</Label>
            <Input
              id="new-number"
              data-ocid="admin.numbers.new_input"
              inputMode="numeric"
              value={newValue}
              onChange={(event) => setNewValue(event.target.value)}
              placeholder="Ej. 42"
              className="font-mono"
            />
          </div>
          <Button
            type="submit"
            data-ocid="admin.numbers.create_button"
            disabled={createNumber.isPending}
            className="rounded-lg"
          >
            {createNumber.isPending ? (
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            ) : (
              <Plus className="size-4" aria-hidden="true" />
            )}
            Agregar
          </Button>
        </form>

        {createError ? (
          <p
            data-ocid="admin.numbers.create_error_state"
            role="alert"
            className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {createError}
          </p>
        ) : null}

        {isLoading ? (
          <p
            data-ocid="admin.numbers.loading_state"
            className="flex items-center gap-2 py-6 text-sm text-muted-foreground"
          >
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Cargando números…
          </p>
        ) : !numbers || numbers.length === 0 ? (
          <div
            data-ocid="admin.numbers.empty_state"
            className="rounded-lg border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground"
          >
            Todavía no hay números en la tabla. Agregá el primero arriba.
          </div>
        ) : (
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {numbers.map((number, index) => (
              <li
                key={String(number.id)}
                data-ocid={`admin.numbers.item.${index + 1}`}
                className="flex flex-col gap-3 rounded-lg border border-border bg-card p-3 shadow-subtle"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="ticket-number text-2xl font-bold text-foreground">
                    {formatNumber(number.value)}
                  </span>
                  <Badge
                    className={cn("rounded-full", STATE_BADGE[number.state])}
                  >
                    {STATE_LABELS[number.state]}
                  </Badge>
                </div>
                <Select
                  value={number.state}
                  onValueChange={(value) =>
                    handleStateChange(number, value as NumberState)
                  }
                >
                  <SelectTrigger
                    data-ocid={`admin.numbers.state_select.${index + 1}`}
                    size="sm"
                    aria-label={`Estado del número ${formatNumber(number.value)}`}
                    className="w-full"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NumberState.available}>
                      Disponible
                    </SelectItem>
                    <SelectItem value={NumberState.reserved}>
                      Reservado
                    </SelectItem>
                    <SelectItem value={NumberState.paid}>Pagado</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    data-ocid={`admin.numbers.edit_button.${index + 1}`}
                    onClick={() => openEdit(number)}
                    className="flex-1 rounded-lg"
                  >
                    <Pencil className="size-3.5" aria-hidden="true" />
                    Editar
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    data-ocid={`admin.numbers.delete_button.${index + 1}`}
                    onClick={() => setDeleting(number)}
                    aria-label={`Eliminar número ${formatNumber(number.value)}`}
                    className="rounded-lg text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="size-3.5" aria-hidden="true" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>

      <Dialog
        open={editing !== null}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
      >
        <DialogContent data-ocid="admin.numbers.edit_dialog">
          <DialogHeader>
            <DialogTitle className="font-display">Editar número</DialogTitle>
            <DialogDescription>
              Cambiá el valor del número. El estado se edita desde la tarjeta.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-number">Valor</Label>
              <Input
                id="edit-number"
                data-ocid="admin.numbers.edit_input"
                inputMode="numeric"
                value={editValue}
                onChange={(event) => setEditValue(event.target.value)}
                className="font-mono"
              />
            </div>
            {editError ? (
              <p
                data-ocid="admin.numbers.edit_error_state"
                role="alert"
                className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
              >
                {editError}
              </p>
            ) : null}
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                data-ocid="admin.numbers.edit_cancel_button"
                onClick={() => setEditing(null)}
                className="rounded-lg"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                data-ocid="admin.numbers.edit_save_button"
                disabled={updateNumber.isPending}
                className="rounded-lg"
              >
                {updateNumber.isPending ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                ) : null}
                Guardar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleting !== null}
        onOpenChange={(open) => {
          if (!open) setDeleting(null);
        }}
      >
        <DialogContent data-ocid="admin.numbers.delete_dialog">
          <DialogHeader>
            <DialogTitle className="font-display">Eliminar número</DialogTitle>
            <DialogDescription>
              {deleting
                ? `Se eliminará el número ${formatNumber(deleting.value)} de la tabla. Esta acción no se puede deshacer.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              data-ocid="admin.numbers.delete_cancel_button"
              onClick={() => setDeleting(null)}
              className="rounded-lg"
            >
              Cancelar
            </Button>
            <Button
              type="button"
              variant="destructive"
              data-ocid="admin.numbers.delete_confirm_button"
              disabled={deleteNumber.isPending}
              onClick={handleDelete}
              className="rounded-lg"
            >
              {deleteNumber.isPending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              ) : (
                <Trash2 className="size-4" aria-hidden="true" />
              )}
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
