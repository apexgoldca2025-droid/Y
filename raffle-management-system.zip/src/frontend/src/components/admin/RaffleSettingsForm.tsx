import type { RaffleSettings } from "@/backend";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useRaffleSettings, useUpdateRaffleSettings } from "@/hooks/useRaffle";
import { dateToTimestamp, timestampToDate } from "@/lib/format";
import { CalendarDays, Loader2, Save } from "lucide-react";
import { type FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";

interface Draft {
  title: string;
  description: string;
  pricePerNumber: string;
  drawDate: string;
  prize: string;
  alias: string;
  cbu: string;
  accountHolder: string;
  amount: string;
}

const EMPTY_DRAFT: Draft = {
  title: "",
  description: "",
  pricePerNumber: "",
  drawDate: "",
  prize: "",
  alias: "",
  cbu: "",
  accountHolder: "",
  amount: "",
};

function toDateInput(timestamp: bigint): string {
  const date = timestampToDate(timestamp);
  if (!date) return "";
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

function draftFromSettings(settings: RaffleSettings): Draft {
  return {
    title: settings.title,
    description: settings.description,
    pricePerNumber: String(settings.pricePerNumber),
    drawDate: toDateInput(settings.drawDate),
    prize: settings.prize,
    alias: settings.payment.alias,
    cbu: settings.payment.cbu,
    accountHolder: settings.payment.accountHolder,
    amount: String(settings.payment.amount),
  };
}

function parseAmount(value: string): bigint | null {
  const trimmed = value.trim();
  if (!/^\d+$/.test(trimmed)) return null;
  return BigInt(trimmed);
}

export function RaffleSettingsForm() {
  const { data: settings, isLoading } = useRaffleSettings();
  const updateSettings = useUpdateRaffleSettings();
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [initialized, setInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (settings && !initialized) {
      setDraft(draftFromSettings(settings));
      setInitialized(true);
    }
  }, [settings, initialized]);

  const set = <K extends keyof Draft>(key: K, value: Draft[K]) => {
    setDraft((current) => ({ ...current, [key]: value }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    const price = parseAmount(draft.pricePerNumber);
    const amount = parseAmount(draft.amount);
    if (!draft.title.trim()) {
      setError("El título de la rifa es obligatorio.");
      return;
    }
    if (price === null) {
      setError("El precio por número debe ser un número entero.");
      return;
    }
    if (amount === null) {
      setError("El monto a transferir debe ser un número entero.");
      return;
    }
    if (!draft.drawDate) {
      setError("Elegí la fecha del sorteo.");
      return;
    }

    const next: RaffleSettings = {
      title: draft.title.trim(),
      description: draft.description.trim(),
      pricePerNumber: price,
      drawDate: dateToTimestamp(new Date(`${draft.drawDate}T12:00:00`)),
      prize: draft.prize.trim(),
      payment: {
        alias: draft.alias.trim(),
        cbu: draft.cbu.trim(),
        accountHolder: draft.accountHolder.trim(),
        amount,
      },
    };

    updateSettings.mutate(next, {
      onSuccess: () => toast.success("Configuración guardada"),
      onError: () =>
        setError(
          "No se pudo guardar la configuración. Verificá tus permisos e intentá de nuevo.",
        ),
    });
  };

  if (isLoading) {
    return (
      <Card
        data-ocid="admin.settings.loading_state"
        className="rounded-xl border shadow-subtle"
      >
        <CardContent className="flex items-center gap-3 py-10 text-muted-foreground">
          <Loader2 className="size-5 animate-spin" aria-hidden="true" />
          Cargando configuración…
        </CardContent>
      </Card>
    );
  }

  return (
    <Card
      data-ocid="admin.settings.card"
      className="rounded-xl border shadow-subtle"
    >
      <CardHeader className="border-b">
        <CardTitle className="font-display text-xl">
          Configuración de la rifa
        </CardTitle>
        <CardDescription>
          Estos datos se muestran en la página pública. Los cambios se reflejan
          al guardar.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="raffle-title">Título</Label>
              <Input
                id="raffle-title"
                data-ocid="admin.settings.title_input"
                value={draft.title}
                onChange={(event) => set("title", event.target.value)}
                placeholder="Rifa solidaria 2026"
              />
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="raffle-description">Descripción</Label>
              <Textarea
                id="raffle-description"
                data-ocid="admin.settings.description_input"
                value={draft.description}
                onChange={(event) => set("description", event.target.value)}
                placeholder="Contá de qué se trata la rifa y a quién ayuda."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="raffle-price">Precio por número</Label>
              <Input
                id="raffle-price"
                data-ocid="admin.settings.price_input"
                inputMode="numeric"
                value={draft.pricePerNumber}
                onChange={(event) => set("pricePerNumber", event.target.value)}
                placeholder="1500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="raffle-draw-date">Fecha del sorteo</Label>
              <div className="relative">
                <Input
                  id="raffle-draw-date"
                  data-ocid="admin.settings.draw_date_input"
                  type="date"
                  value={draft.drawDate}
                  onChange={(event) => set("drawDate", event.target.value)}
                />
                <CalendarDays
                  className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                  aria-hidden="true"
                />
              </div>
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="raffle-prize">Premio</Label>
              <Input
                id="raffle-prize"
                data-ocid="admin.settings.prize_input"
                value={draft.prize}
                onChange={(event) => set("prize", event.target.value)}
                placeholder="Una bicicleta todo terreno"
              />
            </div>
          </div>

          <div className="space-y-4 rounded-lg border border-border bg-muted/40 p-4">
            <div>
              <h3 className="font-display text-sm font-semibold text-foreground">
                Datos de pago
              </h3>
              <p className="text-xs text-muted-foreground">
                Se muestran al participante para transferir el importe.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="payment-alias">Alias</Label>
                <Input
                  id="payment-alias"
                  data-ocid="admin.settings.alias_input"
                  value={draft.alias}
                  onChange={(event) => set("alias", event.target.value)}
                  placeholder="rifa.solidaria.2026"
                  className="font-mono"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-cbu">CBU</Label>
                <Input
                  id="payment-cbu"
                  data-ocid="admin.settings.cbu_input"
                  value={draft.cbu}
                  onChange={(event) => set("cbu", event.target.value)}
                  placeholder="0000000000000000000000"
                  className="font-mono"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-holder">Titular de la cuenta</Label>
                <Input
                  id="payment-holder"
                  data-ocid="admin.settings.holder_input"
                  value={draft.accountHolder}
                  onChange={(event) => set("accountHolder", event.target.value)}
                  placeholder="Nombre y apellido"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="payment-amount">Monto a transferir</Label>
                <Input
                  id="payment-amount"
                  data-ocid="admin.settings.amount_input"
                  inputMode="numeric"
                  value={draft.amount}
                  onChange={(event) => set("amount", event.target.value)}
                  placeholder="1500"
                />
              </div>
            </div>
          </div>

          {error ? (
            <p
              data-ocid="admin.settings.error_state"
              role="alert"
              className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
            >
              {error}
            </p>
          ) : null}

          <div className="flex justify-end">
            <Button
              type="submit"
              data-ocid="admin.settings.save_button"
              disabled={updateSettings.isPending}
              className="rounded-lg"
            >
              {updateSettings.isPending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              ) : (
                <Save className="size-4" aria-hidden="true" />
              )}
              Guardar cambios
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
