import {
  type Participant,
  type ParticipantInput,
  PaymentStatus,
  type ProofBlob,
} from "@/backend";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  useDeleteParticipant,
  useParticipants,
  useUpdateParticipant,
} from "@/hooks/useRaffle";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/format";
import { cn } from "@/lib/utils";
import { ImageOff, Loader2, Pencil, Trash2 } from "lucide-react";
import { type FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";

const STATUS_LABELS: Record<PaymentStatus, string> = {
  [PaymentStatus.pending]: "Pendiente",
  [PaymentStatus.proofSubmitted]: "Comprobante enviado",
  [PaymentStatus.confirmed]: "Confirmado",
};

const STATUS_BADGE: Record<PaymentStatus, string> = {
  [PaymentStatus.pending]: "border-border bg-background text-muted-foreground",
  [PaymentStatus.proofSubmitted]:
    "border-transparent bg-warning/20 text-warning-foreground",
  [PaymentStatus.confirmed]:
    "border-transparent bg-primary text-primary-foreground",
};

interface Draft {
  fullName: string;
  phone: string;
  email: string;
  status: PaymentStatus;
}

/** Render a stored proof blob as an object URL, revoking it on cleanup. */
function ProofPreview({ proof }: { proof: ProofBlob }) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    const bytes = new Uint8Array(proof);
    const objectUrl = URL.createObjectURL(
      new Blob([bytes], { type: "image/*" }),
    );
    setUrl(objectUrl);
    return () => URL.revokeObjectURL(objectUrl);
  }, [proof]);

  if (!url) {
    return (
      <span className="flex size-12 items-center justify-center rounded-md border border-border bg-muted text-muted-foreground">
        <ImageOff className="size-4" aria-hidden="true" />
      </span>
    );
  }

  return (
    <a
      href={url}
      target="_blank"
      rel="noreferrer"
      className="block size-12 overflow-hidden rounded-md border border-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <img
        src={url}
        alt="Comprobante de pago"
        className="size-full object-cover"
      />
    </a>
  );
}

export function ParticipantsTable() {
  const { data: participants, isLoading } = useParticipants();
  const updateParticipant = useUpdateParticipant();
  const deleteParticipant = useDeleteParticipant();

  const [editing, setEditing] = useState<Participant | null>(null);
  const [draft, setDraft] = useState<Draft>({
    fullName: "",
    phone: "",
    email: "",
    status: PaymentStatus.pending,
  });
  const [editError, setEditError] = useState<string | null>(null);

  const [deleting, setDeleting] = useState<Participant | null>(null);

  const openEdit = (participant: Participant) => {
    setEditing(participant);
    setDraft({
      fullName: participant.fullName,
      phone: participant.phone,
      email: participant.email,
      status: participant.paymentStatus,
    });
    setEditError(null);
  };

  const handleEditSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editing) return;
    setEditError(null);

    if (!draft.fullName.trim()) {
      setEditError("El nombre del participante es obligatorio.");
      return;
    }
    if (!draft.phone.trim()) {
      setEditError("El teléfono es obligatorio.");
      return;
    }

    const input: ParticipantInput = {
      fullName: draft.fullName.trim(),
      phone: draft.phone.trim(),
      email: draft.email.trim(),
    };

    updateParticipant.mutate(
      { id: editing.id, input, status: draft.status },
      {
        onSuccess: () => {
          setEditing(null);
          toast.success("Participante actualizado");
        },
        onError: () =>
          setEditError(
            "No se pudieron guardar los datos. Verificá la información e intentá de nuevo.",
          ),
      },
    );
  };

  const handleDelete = () => {
    if (!deleting) return;
    const target = deleting;
    deleteParticipant.mutate(target.id, {
      onSuccess: () => {
        setDeleting(null);
        toast.success("Participante eliminado junto con sus números");
      },
      onError: () => toast.error("No se pudo eliminar el participante."),
    });
  };

  return (
    <Card
      data-ocid="admin.participants.card"
      className="rounded-xl border shadow-subtle"
    >
      <CardHeader className="border-b">
        <CardTitle className="font-display text-xl">Participantes</CardTitle>
        <CardDescription>
          Datos, números reservados, estado de pago y comprobante de cada
          participante.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p
            data-ocid="admin.participants.loading_state"
            className="flex items-center gap-2 py-6 text-sm text-muted-foreground"
          >
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Cargando participantes…
          </p>
        ) : !participants || participants.length === 0 ? (
          <div
            data-ocid="admin.participants.empty_state"
            className="rounded-lg border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground"
          >
            Todavía no hay participantes registrados.
          </div>
        ) : (
          <Table data-ocid="admin.participants.table">
            <TableHeader>
              <TableRow>
                <TableHead>Participante</TableHead>
                <TableHead>Contacto</TableHead>
                <TableHead>Números</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Comprobante</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {participants.map((participant, index) => (
                <TableRow
                  key={String(participant.id)}
                  data-ocid={`admin.participants.row.${index + 1}`}
                >
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium text-foreground">
                        {participant.fullName}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDateTime(participant.createdAt)}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-mono text-xs text-foreground">
                        {participant.phone}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {participant.email || "Sin correo"}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex max-w-[12rem] flex-wrap gap-1">
                      {participant.numbers.length === 0 ? (
                        <span className="text-xs text-muted-foreground">
                          Sin números
                        </span>
                      ) : (
                        participant.numbers.map((value) => (
                          <span
                            key={String(value)}
                            className="ticket-number rounded border border-border bg-muted px-1.5 py-0.5 text-xs text-foreground"
                          >
                            {formatNumber(value)}
                          </span>
                        ))
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm text-foreground">
                    {formatCurrency(participant.totalAmount)}
                  </TableCell>
                  <TableCell>
                    <Badge
                      className={cn(
                        "rounded-full",
                        STATUS_BADGE[participant.paymentStatus],
                      )}
                    >
                      {STATUS_LABELS[participant.paymentStatus]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {participant.proof ? (
                      <ProofPreview proof={participant.proof} />
                    ) : (
                      <span className="text-xs text-muted-foreground">
                        Sin comprobante
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        data-ocid={`admin.participants.edit_button.${index + 1}`}
                        onClick={() => openEdit(participant)}
                        className="rounded-lg"
                      >
                        <Pencil className="size-3.5" aria-hidden="true" />
                        Editar
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        data-ocid={`admin.participants.delete_button.${index + 1}`}
                        onClick={() => setDeleting(participant)}
                        aria-label={`Eliminar participante ${participant.fullName}`}
                        className="rounded-lg text-destructive hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="size-3.5" aria-hidden="true" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog
        open={editing !== null}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
      >
        <DialogContent data-ocid="admin.participants.edit_dialog">
          <DialogHeader>
            <DialogTitle className="font-display">
              Editar participante
            </DialogTitle>
            <DialogDescription>
              Actualizá los datos de contacto y el estado de pago.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="participant-name">Nombre completo</Label>
              <Input
                id="participant-name"
                data-ocid="admin.participants.name_input"
                value={draft.fullName}
                onChange={(event) =>
                  setDraft((current) => ({
                    ...current,
                    fullName: event.target.value,
                  }))
                }
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="participant-phone">Teléfono</Label>
                <Input
                  id="participant-phone"
                  data-ocid="admin.participants.phone_input"
                  value={draft.phone}
                  onChange={(event) =>
                    setDraft((current) => ({
                      ...current,
                      phone: event.target.value,
                    }))
                  }
                  className="font-mono"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="participant-email">Correo</Label>
                <Input
                  id="participant-email"
                  data-ocid="admin.participants.email_input"
                  type="email"
                  value={draft.email}
                  onChange={(event) =>
                    setDraft((current) => ({
                      ...current,
                      email: event.target.value,
                    }))
                  }
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="participant-status">Estado de pago</Label>
              <Select
                value={draft.status}
                onValueChange={(value) =>
                  setDraft((current) => ({
                    ...current,
                    status: value as PaymentStatus,
                  }))
                }
              >
                <SelectTrigger
                  id="participant-status"
                  data-ocid="admin.participants.status_select"
                  className="w-full"
                >
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={PaymentStatus.pending}>
                    Pendiente
                  </SelectItem>
                  <SelectItem value={PaymentStatus.proofSubmitted}>
                    Comprobante enviado
                  </SelectItem>
                  <SelectItem value={PaymentStatus.confirmed}>
                    Confirmado
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            {editError ? (
              <p
                data-ocid="admin.participants.edit_error_state"
                role="alert"
                className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
              >
                {editError}
              </p>
            ) : null}
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                data-ocid="admin.participants.edit_cancel_button"
                onClick={() => setEditing(null)}
                className="rounded-lg"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                data-ocid="admin.participants.edit_save_button"
                disabled={updateParticipant.isPending}
                className="rounded-lg"
              >
                {updateParticipant.isPending ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                ) : null}
                Guardar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleting !== null}
        onOpenChange={(open) => {
          if (!open) setDeleting(null);
        }}
      >
        <DialogContent data-ocid="admin.participants.delete_dialog">
          <DialogHeader>
            <DialogTitle className="font-display">
              Eliminar participante
            </DialogTitle>
            <DialogDescription>
              {deleting
                ? `Se eliminará a ${deleting.fullName} junto con sus ${deleting.numbers.length} número(s), que volverán a estar disponibles. Esta acción no se puede deshacer.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              data-ocid="admin.participants.delete_cancel_button"
              onClick={() => setDeleting(null)}
              className="rounded-lg"
            >
              Cancelar
            </Button>
            <Button
              type="button"
              variant="destructive"
              data-ocid="admin.participants.delete_confirm_button"
              disabled={deleteParticipant.isPending}
              onClick={handleDelete}
              className="rounded-lg"
            >
              {deleteParticipant.isPending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              ) : (
                <Trash2 className="size-4" aria-hidden="true" />
              )}
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
