import { SignInButton } from "@/components/InternetIdentity";
import { cn } from "@/lib/utils";
import { Link } from "@tanstack/react-router";
import { Menu, ShieldCheck, Ticket, X } from "lucide-react";
import { type ReactNode, useState } from "react";

const navLinks = [
  { to: "/", label: "Inicio" },
  { to: "/admin", label: "Panel" },
] as const;

export function Layout({ children }: { children: ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const year = new Date().getFullYear();

  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link
            to="/"
            data-ocid="nav.home_link"
            className="group flex items-center gap-2.5 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card"
            onClick={() => setMenuOpen(false)}
          >
            <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-subtle transition-smooth group-hover:brightness-110">
              <Ticket className="size-5" aria-hidden="true" />
            </span>
            <span className="flex flex-col leading-none">
              <span className="font-display text-lg font-bold tracking-tight text-foreground">
                RifaYa
              </span>
              <span className="text-[0.65rem] font-medium uppercase tracking-widest text-muted-foreground">
                Rifa solidaria
              </span>
            </span>
          </Link>

          <nav
            aria-label="Navegación principal"
            className="hidden items-center gap-1 md:flex"
          >
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                data-ocid={`nav.${link.to === "/" ? "home" : "admin"}_link`}
                activeOptions={{ exact: link.to === "/" }}
                className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-smooth hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                activeProps={{ className: "text-foreground" }}
              >
                {link.label}
              </Link>
            ))}
            <Link
              to="/admin"
              data-ocid="nav.admin_panel_link"
              className="ml-2 inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium text-foreground transition-smooth hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
              Administración
            </Link>
          </nav>

          <button
            type="button"
            data-ocid="nav.menu_toggle"
            aria-label={menuOpen ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={menuOpen}
            className="inline-flex size-10 items-center justify-center rounded-lg border border-border text-foreground transition-smooth hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring md:hidden"
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? (
              <X className="size-5" aria-hidden="true" />
            ) : (
              <Menu className="size-5" aria-hidden="true" />
            )}
          </button>
        </div>

        <div
          className={cn(
            "overflow-hidden border-t border-border bg-card md:hidden",
            menuOpen ? "block" : "hidden",
          )}
        >
          <nav
            aria-label="Navegación móvil"
            className="mx-auto flex w-full max-w-6xl flex-col gap-1 px-4 py-3 sm:px-6"
          >
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                data-ocid={`nav.mobile_${link.to === "/" ? "home" : "admin"}_link`}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-smooth hover:bg-muted hover:text-foreground"
                activeProps={{ className: "text-foreground" }}
                onClick={() => setMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <Link
              to="/admin"
              data-ocid="nav.mobile_admin_panel_link"
              className="mt-1 inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2.5 text-sm font-medium text-foreground transition-smooth hover:bg-muted"
              onClick={() => setMenuOpen(false)}
            >
              <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
              Administración
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border bg-muted/40">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-4 px-4 py-10 sm:px-6 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2.5">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Ticket className="size-4" aria-hidden="true" />
            </span>
            <div className="flex flex-col leading-tight">
              <span className="font-display text-sm font-semibold text-foreground">
                RifaYa
              </span>
              <span className="text-xs text-muted-foreground">
                Gestión transparente de tu rifa solidaria
              </span>
            </div>
          </div>
          <div className="flex flex-col gap-2 text-xs text-muted-foreground md:items-end">
            <SignInButton className="w-fit rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-foreground transition-smooth hover:bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" />
            <p>
              © {year}. Built with love using{" "}
              <a
                href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-foreground underline-offset-4 hover:underline"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
