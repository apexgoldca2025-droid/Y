import type { Timestamp } from "@/backend";

/**
 * Motoko `Time.now()` values are nanosecond bigints. Convert through this
 * helper before any JavaScript Date operation.
 */
export function timestampToDate(timestamp: Timestamp): Date | null {
  const date = new Date(Number(timestamp / 1_000_000n));
  return Number.isNaN(date.getTime()) ? null : date;
}

const currencyFormatter = new Intl.NumberFormat("es-AR", {
  style: "currency",
  currency: "ARS",
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

/** Format a whole-peso amount (backend stores amounts as integer Nat). */
export function formatCurrency(amount: bigint | number): string {
  const value = typeof amount === "bigint" ? Number(amount) : amount;
  if (!Number.isFinite(value)) return "—";
  return currencyFormatter.format(value);
}

const dateFormatter = new Intl.DateTimeFormat("es-AR", {
  day: "2-digit",
  month: "long",
  year: "numeric",
});

const dateTimeFormatter = new Intl.DateTimeFormat("es-AR", {
  day: "2-digit",
  month: "short",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
});

/** Format a backend timestamp as a long date, e.g. "28 de diciembre de 2026". */
export function formatDate(timestamp: Timestamp): string {
  const date = timestampToDate(timestamp);
  return date ? dateFormatter.format(date) : "Fecha a confirmar";
}

/** Format a backend timestamp with time, e.g. "28 dic 2026, 18:30". */
export function formatDateTime(timestamp: Timestamp): string {
  const date = timestampToDate(timestamp);
  return date ? dateTimeFormatter.format(date) : "—";
}

/** Convert a Date to the nanosecond timestamp the backend expects. */
export function dateToTimestamp(date: Date): Timestamp {
  return BigInt(date.getTime()) * 1_000_000n;
}

/** Format a raffle number as a two-digit ticket stub, e.g. 7 -> "07". */
export function formatNumber(value: bigint | number): string {
  const n = typeof value === "bigint" ? Number(value) : value;
  return Number.isFinite(n) ? String(n).padStart(2, "0") : "—";
}
