import { createActor } from "@/backend";
import type {
  NumberId,
  NumberState,
  Participant,
  ParticipantId,
  ParticipantInput,
  PaymentStatus,
  ProofBlob,
  RaffleNumber,
  RaffleSettings,
} from "@/backend";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

export const raffleKeys = {
  settings: ["raffle", "settings"] as const,
  numbers: ["raffle", "numbers"] as const,
  participants: ["raffle", "participants"] as const,
  isAdmin: ["raffle", "isAdmin"] as const,
};

/** Public: the raffle configuration shown on the landing page. */
export function useRaffleSettings() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<RaffleSettings>({
    queryKey: raffleKeys.settings,
    queryFn: async () => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.getRaffleSettings();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Public: the full number table with each cell's state. */
export function useNumberTable() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<RaffleNumber[]>({
    queryKey: raffleKeys.numbers,
    queryFn: async () => {
      if (!actor) return [];
      return actor.getNumberTable();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Public: reserve a set of numbers for a participant. */
export function useReserveNumbers() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      input,
      selected,
    }: {
      input: ParticipantInput;
      selected: bigint[];
    }): Promise<ParticipantId> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.reserveNumbers(input, selected);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.numbers });
      void queryClient.invalidateQueries({ queryKey: raffleKeys.participants });
    },
  });
}

/** Public: attach a payment proof image to a participant. */
export function useAttachProof() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      proof,
    }: {
      id: ParticipantId;
      proof: ProofBlob;
    }): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.attachProof(id, proof);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.participants });
    },
  });
}

/** Admin: whether the signed-in caller is an administrator. */
export function useIsAdmin() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<boolean>({
    queryKey: raffleKeys.isAdmin,
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Admin: update the raffle configuration. */
export function useUpdateRaffleSettings() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (next: RaffleSettings): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.updateRaffleSettings(next);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.settings });
    },
  });
}

/** Admin: create a new number in the table. */
export function useCreateNumber() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (value: bigint): Promise<NumberId> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.createNumber(value);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.numbers });
    },
  });
}

/** Admin: change a number's value. */
export function useUpdateNumber() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      value,
    }: {
      id: NumberId;
      value: bigint;
    }): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.updateNumber(id, value);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.numbers });
    },
  });
}

/** Admin: remove a number from the table. */
export function useDeleteNumber() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: NumberId): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.deleteNumber(id);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.numbers });
    },
  });
}

/** Admin: set a number's state (available / reserved / paid). */
export function useSetNumberState() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      state,
    }: {
      id: NumberId;
      state: NumberState;
    }): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.setNumberState(id, state);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.numbers });
    },
  });
}

/** Admin: list every participant with their numbers and payment status. */
export function useParticipants() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Participant[]>({
    queryKey: raffleKeys.participants,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listParticipants();
    },
    enabled: !!actor && !isFetching,
  });
}

/** Admin: edit a participant's details and payment status. */
export function useUpdateParticipant() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      input,
      status,
    }: {
      id: ParticipantId;
      input: ParticipantInput;
      status: PaymentStatus;
    }): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.updateParticipant(id, input, status);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.participants });
    },
  });
}

/** Admin: delete a participant. */
export function useDeleteParticipant() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: ParticipantId): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.deleteParticipant(id);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.participants });
    },
  });
}

/** Admin: reset the whole raffle back to its initial state. */
export function useResetRaffle() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (): Promise<void> => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.resetRaffle();
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: raffleKeys.numbers });
      void queryClient.invalidateQueries({ queryKey: raffleKeys.participants });
      void queryClient.invalidateQueries({ queryKey: raffleKeys.settings });
    },
  });
}
