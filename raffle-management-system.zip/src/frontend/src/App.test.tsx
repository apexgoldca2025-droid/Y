import { setIdentityForTest } from "@/__tests__/setup";
import { renderWithActor } from "@/__tests__/test-utils";
import type { backendInterface } from "@/backend";
import { screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import App from "./App";

type AdminActor = Pick<
  backendInterface,
  "getRaffleSettings" | "getNumberTable" | "isCallerAdmin"
>;

function makeActor(overrides: Partial<AdminActor> = {}): AdminActor {
  return {
    getRaffleSettings: vi.fn<backendInterface["getRaffleSettings"]>(
      async () => ({
        title: "Rifa solidaria 2026",
        description: "Ayudanos a recaudar fondos.",
        pricePerNumber: 1500n,
        drawDate: 1_800_000_000_000_000_000n,
        prize: "Una bicicleta",
        payment: {
          alias: "rifa.solidaria",
          cbu: "0000000000000000000000",
          accountHolder: "María González",
          amount: 1500n,
        },
      }),
    ),
    getNumberTable: vi.fn<backendInterface["getNumberTable"]>(async () => []),
    isCallerAdmin: vi.fn<backendInterface["isCallerAdmin"]>(async () => false),
    ...overrides,
  };
}

describe("admin access control", () => {
  it("shows the sign-in gate instead of the admin panel for an unauthenticated visitor", async () => {
    setIdentityForTest();
    window.history.pushState({}, "", "/admin");
    renderWithActor(<App />, makeActor());

    expect(
      await screen.findByTestId("admin.sign_in_state"),
    ).toBeInTheDocument();
    expect(screen.queryByTestId("admin.page")).not.toBeInTheDocument();
  });

  it("denies the admin panel to a signed-in non-administrator", async () => {
    const identity = {
      getPrincipal: () => ({
        isAnonymous: () => false,
        toText: () => "user-1",
      }),
    };
    setIdentityForTest({ identity: identity as never });
    window.history.pushState({}, "", "/admin");
    renderWithActor(<App />, makeActor());

    expect(
      await screen.findByTestId("admin.access_denied_state"),
    ).toBeInTheDocument();
    expect(screen.queryByTestId("admin.page")).not.toBeInTheDocument();
  });
});
