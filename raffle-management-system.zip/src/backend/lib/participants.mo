import Iter "mo:core/Iter";
import Map "mo:core/Map";
import Time "mo:core/Time";
import Types "../types/participants";
import RaffleTypes "../types/raffle";

module {
  // Find the raffle number whose displayed value matches `value`.
  func findNumberByValue(
    numbers : Map.Map<RaffleTypes.NumberId, RaffleTypes.RaffleNumber>,
    value : Nat,
  ) : ?RaffleTypes.RaffleNumber {
    numbers.values().find(func n = n.value == value);
  };

  public func listParticipants(participants : Map.Map<Types.ParticipantId, Types.Participant>) : [Types.Participant] {
    participants.values().toArray();
  };

  public func reserveNumbers(
    participants : Map.Map<Types.ParticipantId, Types.Participant>,
    numbers : Map.Map<RaffleTypes.NumberId, RaffleTypes.RaffleNumber>,
    nextId : { var value : Nat },
    input : Types.ParticipantInput,
    selected : [Nat],
    pricePerNumber : Nat,
  ) : Types.ParticipantId {
    let id = nextId.value;
    nextId.value := id + 1;
    let participant : Types.Participant = {
      id;
      fullName = input.fullName;
      phone = input.phone;
      email = input.email;
      numbers = selected;
      totalAmount = selected.size() * pricePerNumber;
      paymentStatus = #pending;
      proof = null;
      createdAt = Time.now();
    };
    participants.add(id, participant);
    id;
  };

  public func attachProof(
    participants : Map.Map<Types.ParticipantId, Types.Participant>,
    id : Types.ParticipantId,
    proof : Types.ProofBlob,
  ) : () {
    switch (participants.get(id)) {
      case (?p) {
        participants.add(id, { p with proof = ?proof; paymentStatus = #proofSubmitted });
      };
      case null {};
    };
  };

  public func updateParticipant(
    participants : Map.Map<Types.ParticipantId, Types.Participant>,
    id : Types.ParticipantId,
    input : Types.ParticipantInput,
    status : Types.PaymentStatus,
  ) : () {
    switch (participants.get(id)) {
      case (?p) {
        participants.add(id, {
          p with
          fullName = input.fullName;
          phone = input.phone;
          email = input.email;
          paymentStatus = status;
        });
      };
      case null {};
    };
  };

  public func deleteParticipant(
    participants : Map.Map<Types.ParticipantId, Types.Participant>,
    numbers : Map.Map<RaffleTypes.NumberId, RaffleTypes.RaffleNumber>,
    id : Types.ParticipantId,
  ) : () {
    switch (participants.get(id)) {
      case (?p) {
        // Return the participant's numbers to the available pool.
        for (value in p.numbers.values()) {
          switch (findNumberByValue(numbers, value)) {
            case (?n) {
              numbers.add(n.id, { n with state = #available });
            };
            case null {};
          };
        };
        participants.remove(id);
      };
      case null {};
    };
  };

  public func clearAll(participants : Map.Map<Types.ParticipantId, Types.Participant>) : () {
    participants.clear();
  };
};
