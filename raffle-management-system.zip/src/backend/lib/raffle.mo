import Map "mo:core/Map";
import Nat "mo:core/Nat";
import Runtime "mo:core/Runtime";
import Types "../types/raffle";

module {
  public func getSettings(settings : { var current : Types.RaffleSettings }) : Types.RaffleSettings {
    settings.current;
  };

  public func updateSettings(settings : { var current : Types.RaffleSettings }, next : Types.RaffleSettings) : () {
    settings.current := next;
  };

  public func listNumbers(numbers : Map.Map<Types.NumberId, Types.RaffleNumber>) : [Types.RaffleNumber] {
    numbers.values().toArray().sort(func(a, b) = Nat.compare(a.value, b.value));
  };

  public func createNumber(numbers : Map.Map<Types.NumberId, Types.RaffleNumber>, nextId : { var value : Nat }, value : Nat) : Types.NumberId {
    let id = nextId.value;
    nextId.value := id + 1;
    numbers.add(id, { id; value; state = #available });
    id;
  };

  public func updateNumber(numbers : Map.Map<Types.NumberId, Types.RaffleNumber>, id : Types.NumberId, value : Nat) : () {
    let existing = numbers.get(id) ?? Runtime.trap("Number not found");
    numbers.add(id, { existing with value });
  };

  public func deleteNumber(numbers : Map.Map<Types.NumberId, Types.RaffleNumber>, id : Types.NumberId) : () {
    if (not numbers.containsKey(id)) {
      Runtime.trap("Number not found");
    };
    numbers.remove(id);
  };

  public func setNumberState(numbers : Map.Map<Types.NumberId, Types.RaffleNumber>, id : Types.NumberId, state : Types.NumberState) : () {
    let existing = numbers.get(id) ?? Runtime.trap("Number not found");
    numbers.add(id, { existing with state });
  };

  public func resetRaffle(numbers : Map.Map<Types.NumberId, Types.RaffleNumber>) : () {
    let snapshot = numbers.values().toArray();
    for (number in snapshot.values()) {
      numbers.add(number.id, { number with state = #available });
    };
  };
};
