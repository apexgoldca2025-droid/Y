import Common "common";

module {
  public type Timestamp = Common.Timestamp;
  public type ParticipantId = Common.ParticipantId;
  public type ProofBlob = Common.ProofBlob;

  public type PaymentStatus = {
    #pending;
    #proofSubmitted;
    #confirmed;
  };

  public type Participant = {
    id : ParticipantId;
    fullName : Text;
    phone : Text;
    email : Text;
    numbers : [Nat];
    totalAmount : Nat;
    paymentStatus : PaymentStatus;
    proof : ?ProofBlob;
    createdAt : Timestamp;
  };

  public type ParticipantInput = {
    fullName : Text;
    phone : Text;
    email : Text;
  };

  public type ParticipantError = {
    #numberNotAvailable : [Nat];
    #invalidParticipantData : Text;
    #unauthorized;
    #participantNotFound : ParticipantId;
  };
};
