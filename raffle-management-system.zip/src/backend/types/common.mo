import Storage "mo:caffeineai-object-storage/Storage";

module {
  public type Timestamp = Int;
  public type NumberId = Nat;
  public type ParticipantId = Nat;
  public type ProofBlob = Storage.ExternalBlob;
};
