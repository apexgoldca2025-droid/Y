import Common "common";

module {
  public type Timestamp = Common.Timestamp;
  public type NumberId = Common.NumberId;

  public type PaymentDetails = {
    alias : Text;
    cbu : Text;
    accountHolder : Text;
    amount : Nat;
  };

  public type RaffleSettings = {
    title : Text;
    description : Text;
    pricePerNumber : Nat;
    drawDate : Timestamp;
    prize : Text;
    payment : PaymentDetails;
  };

  public type NumberState = {
    #available;
    #reserved;
    #paid;
  };

  public type RaffleNumber = {
    id : NumberId;
    value : Nat;
    state : NumberState;
  };

  public type RaffleError = {
    #numberNotAvailable : [Nat];
    #invalidParticipantData : Text;
    #unauthorized;
    #numberNotFound : Nat;
  };
};
