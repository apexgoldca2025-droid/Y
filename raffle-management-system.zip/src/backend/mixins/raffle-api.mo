import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Types "../types/raffle";
import ParticipantTypes "../types/participants";
import RaffleLib "../lib/raffle";
import ParticipantsLib "../lib/participants";

mixin (
  accessControlState : AccessControl.AccessControlState,
  settings : { var current : Types.RaffleSettings },
  numbers : Map.Map<Types.NumberId, Types.RaffleNumber>,
  nextNumberId : { var value : Nat },
  participants : Map.Map<ParticipantTypes.ParticipantId, ParticipantTypes.Participant>,
) {
  func requireAdmin(caller : Principal) : () {
    if (not AccessControl.hasPermission(accessControlState, caller, #admin)) {
      Runtime.trap("Unauthorized: Only admins can perform this action");
    };
  };

  public query func getRaffleSettings() : async Types.RaffleSettings {
    RaffleLib.getSettings(settings);
  };

  public query func getNumberTable() : async [Types.RaffleNumber] {
    RaffleLib.listNumbers(numbers);
  };

  public shared ({ caller }) func updateRaffleSettings(next : Types.RaffleSettings) : async () {
    requireAdmin(caller);
    RaffleLib.updateSettings(settings, next);
  };

  public shared ({ caller }) func createNumber(value : Nat) : async Types.NumberId {
    requireAdmin(caller);
    RaffleLib.createNumber(numbers, nextNumberId, value);
  };

  public shared ({ caller }) func updateNumber(id : Types.NumberId, value : Nat) : async () {
    requireAdmin(caller);
    if (not numbers.containsKey(id)) {
      Runtime.trap("Number not found");
    };
    RaffleLib.updateNumber(numbers, id, value);
  };

  public shared ({ caller }) func deleteNumber(id : Types.NumberId) : async () {
    requireAdmin(caller);
    if (not numbers.containsKey(id)) {
      Runtime.trap("Number not found");
    };
    RaffleLib.deleteNumber(numbers, id);
  };

  public shared ({ caller }) func setNumberState(id : Types.NumberId, state : Types.NumberState) : async () {
    requireAdmin(caller);
    if (not numbers.containsKey(id)) {
      Runtime.trap("Number not found");
    };
    RaffleLib.setNumberState(numbers, id, state);
  };

  public shared ({ caller }) func resetRaffle() : async () {
    requireAdmin(caller);
    RaffleLib.resetRaffle(numbers);
    ParticipantsLib.clearAll(participants);
  };
};
