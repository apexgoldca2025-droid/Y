import Array "mo:core/Array";
import Iter "mo:core/Iter";
import Map "mo:core/Map";
import Nat "mo:core/Nat";
import Runtime "mo:core/Runtime";
import Text "mo:core/Text";
import AccessControl "mo:caffeineai-authorization/access-control";
import Types "../types/participants";
import RaffleTypes "../types/raffle";
import ParticipantsLib "../lib/participants";

mixin (
  accessControlState : AccessControl.AccessControlState,
  settings : { var current : RaffleTypes.RaffleSettings },
  participants : Map.Map<Types.ParticipantId, Types.Participant>,
  numbers : Map.Map<RaffleTypes.NumberId, RaffleTypes.RaffleNumber>,
  nextParticipantId : { var value : Nat },
) {
  // Find the raffle number whose displayed value matches `value`.
  func findNumberByValue(value : Nat) : ?RaffleTypes.RaffleNumber {
    numbers.values().find(func n = n.value == value);
  };

  // Validate the participant's personal data, returning a message when invalid.
  func validateInput(input : Types.ParticipantInput) : ?Text {
    if (input.fullName.size() == 0) {
      return ?"El nombre completo es obligatorio";
    };
    if (input.phone.size() == 0) {
      return ?"El teléfono es obligatorio";
    };
    if (input.email.size() == 0) {
      return ?"El correo electrónico es obligatorio";
    };
    null;
  };

  public shared func reserveNumbers(input : Types.ParticipantInput, selected : [Nat]) : async Types.ParticipantId {
    switch (validateInput(input)) {
      case (?message) { Runtime.trap(message) };
      case null {};
    };
    if (selected.size() == 0) {
      Runtime.trap("Debe seleccionar al menos un número");
    };

    // Reject the reservation when any requested number is not available.
    let unavailable = selected.filter(func value = switch (findNumberByValue(value)) {
      case (?n) { n.state != #available };
      case null { true };
    });
    if (unavailable.size() > 0) {
      Runtime.trap("Números no disponibles: " # unavailable.map(func n = n.toText()).values().join(", "));
    };

    let id = ParticipantsLib.reserveNumbers(
      participants,
      numbers,
      nextParticipantId,
      input,
      selected,
      settings.current.pricePerNumber,
    );

    // Mark the reserved numbers as reserved.
    for (value in selected.values()) {
      switch (findNumberByValue(value)) {
        case (?n) { numbers.add(n.id, { n with state = #reserved }) };
        case null {};
      };
    };

    id;
  };

  public shared func attachProof(id : Types.ParticipantId, proof : Types.ProofBlob) : async () {
    switch (participants.get(id)) {
      case null { Runtime.trap("Participante no encontrado") };
      case (?_) {};
    };
    ParticipantsLib.attachProof(participants, id, proof);
  };

  public query ({ caller }) func listParticipants() : async [Types.Participant] {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can list participants");
    };
    ParticipantsLib.listParticipants(participants);
  };

  public shared ({ caller }) func updateParticipant(id : Types.ParticipantId, input : Types.ParticipantInput, status : Types.PaymentStatus) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can update participants");
    };
    switch (validateInput(input)) {
      case (?message) { Runtime.trap(message) };
      case null {};
    };
    switch (participants.get(id)) {
      case null { Runtime.trap("Participante no encontrado") };
      case (?_) {};
    };
    ParticipantsLib.updateParticipant(participants, id, input, status);
  };

  public shared ({ caller }) func deleteParticipant(id : Types.ParticipantId) : async () {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can delete participants");
    };
    switch (participants.get(id)) {
      case null { Runtime.trap("Participante no encontrado") };
      case (?_) {};
    };
    ParticipantsLib.deleteParticipant(participants, numbers, id);
  };
};
