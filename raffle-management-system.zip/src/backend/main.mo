import Map "mo:core/Map";
import Iter "mo:core/Iter";
import Nat "mo:core/Nat";
import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import MixinObjectStorage "mo:caffeineai-object-storage/Mixin";
import OQL "mo:caffeineai-oql";
import Expose "mo:caffeineai-oql/Expose";
import Entity "mo:caffeineai-oql/Entity";
import NatValue "mo:caffeineai-oql/NatValue";
import TextValue "mo:caffeineai-oql/TextValue";
import IntValue "mo:caffeineai-oql/IntValue";
import RaffleTypes "types/raffle";
import ParticipantTypes "types/participants";
import RaffleApi "mixins/raffle-api";
import ParticipantsApi "mixins/participants-api";
import ApiDocMixin "mixins/api-doc";

actor {
  let accessControlState : AccessControl.AccessControlState;
  include MixinAuthorization(accessControlState, null);
  include MixinObjectStorage();

  let settings : { var current : RaffleTypes.RaffleSettings };
  let numbers : Map.Map<RaffleTypes.NumberId, RaffleTypes.RaffleNumber>;
  let nextNumberId : { var value : Nat };
  let participants : Map.Map<ParticipantTypes.ParticipantId, ParticipantTypes.Participant>;
  let nextParticipantId : { var value : Nat };

  include RaffleApi(accessControlState, settings, numbers, nextNumberId, participants);
  include ParticipantsApi(accessControlState, settings, participants, numbers, nextParticipantId);

  // --- OQL entities ---------------------------------------------------------

  func numberStateText(state : RaffleTypes.NumberState) : Text {
    switch (state) {
      case (#available) { "available" };
      case (#reserved) { "reserved" };
      case (#paid) { "paid" };
    };
  };

  func paymentStatusText(status : ParticipantTypes.PaymentStatus) : Text {
    switch (status) {
      case (#pending) { "pending" };
      case (#proofSubmitted) { "proofSubmitted" };
      case (#confirmed) { "confirmed" };
    };
  };

  func settingsIter() : Iter.Iter<RaffleTypes.RaffleSettings> {
    [settings.current].values();
  };

  include Expose({
    entities = [
      // The published number table is world-readable.
      OQL.Entity.manual<RaffleTypes.RaffleNumber>(
        "raffleNumber",
        func () = numbers.values(),
        "RaffleNumber",
        "id",
      )
        .sample({ id = 0; value = 0; state = #available })
        .payload("id", func n = n.id)
        .payload("value", func n = n.value)
        .payload("state", func n = numberStateText(n.state))
        .public_()
        .build(),
      // Public raffle configuration.
      OQL.Entity.manual<RaffleTypes.RaffleSettings>(
        "raffleSettings",
        settingsIter,
        "RaffleSettings",
        "title",
      )
        .sample({
          title = "";
          description = "";
          pricePerNumber = 0;
          drawDate = 0;
          prize = "";
          payment = { alias = ""; cbu = ""; accountHolder = ""; amount = 0 };
        })
        .payload("title", func s = s.title)
        .payload("description", func s = s.description)
        .payload("pricePerNumber", func s = s.pricePerNumber)
        .payload("drawDate", func s = s.drawDate)
        .payload("prize", func s = s.prize)
        .payload("paymentAlias", func s = s.payment.alias)
        .payload("paymentCbu", func s = s.payment.cbu)
        .payload("paymentAccountHolder", func s = s.payment.accountHolder)
        .payload("paymentAmount", func s = s.payment.amount)
        .public_()
        .build(),
      // Participant personal data is private to the administrator/agent.
      OQL.Entity.manual<ParticipantTypes.Participant>(
        "participant",
        func () = participants.values(),
        "Participant",
        "id",
      )
        .sample({
          id = 0;
          fullName = "";
          phone = "";
          email = "";
          numbers = [];
          totalAmount = 0;
          paymentStatus = #pending;
          proof = null;
          createdAt = 0;
        })
        .payload("id", func p = p.id)
        .payload("fullName", func p = p.fullName)
        .payload("phone", func p = p.phone)
        .payload("email", func p = p.email)
        .payload("numbers", func p = p.numbers.map(func n = n.toText()).values().join(", "))
        .payload("totalAmount", func p = p.totalAmount)
        .payload("paymentStatus", func p = paymentStatusText(p.paymentStatus))
        .payload("createdAt", func p = p.createdAt)
        .controllerOnly()
        .build(),
    ];
  });

  include ApiDocMixin();
};
