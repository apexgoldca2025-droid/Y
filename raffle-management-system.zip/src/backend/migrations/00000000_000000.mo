import Map "mo:core/Map";
import AccessControl "mo:caffeineai-authorization/access-control";

module {
  type PaymentDetails = {
    alias : Text;
    cbu : Text;
    accountHolder : Text;
    amount : Nat;
  };

  type RaffleSettings = {
    title : Text;
    description : Text;
    pricePerNumber : Nat;
    drawDate : Int;
    prize : Text;
    payment : PaymentDetails;
  };

  type NumberState = {
    #available;
    #reserved;
    #paid;
  };

  type RaffleNumber = {
    id : Nat;
    value : Nat;
    state : NumberState;
  };

  type PaymentStatus = {
    #pending;
    #proofSubmitted;
    #confirmed;
  };

  type Participant = {
    id : Nat;
    fullName : Text;
    phone : Text;
    email : Text;
    numbers : [Nat];
    totalAmount : Nat;
    paymentStatus : PaymentStatus;
    proof : ?Blob;
    createdAt : Int;
  };

  public type OldActor = {};

  public type NewActor = {
    accessControlState : AccessControl.AccessControlState;
    settings : { var current : RaffleSettings };
    numbers : Map.Map<Nat, RaffleNumber>;
    nextNumberId : { var value : Nat };
    participants : Map.Map<Nat, Participant>;
    nextParticipantId : { var value : Nat };
  };

  public func migration(_ : OldActor) : NewActor {
    {
      accessControlState = AccessControl.initState();
      settings = {
        var current = {
          title = "";
          description = "";
          pricePerNumber = 0;
          drawDate = 0;
          prize = "";
          payment = { alias = ""; cbu = ""; accountHolder = ""; amount = 0 };
        };
      };
      numbers = Map.empty();
      nextNumberId = { var value = 0 };
      participants = Map.empty();
      nextParticipantId = { var value = 0 };
    };
  };
};
