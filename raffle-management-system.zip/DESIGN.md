# Design Brief

## Direction

Ticket Ledger — a clean, trustworthy raffle platform where the number grid is the hero and every reservation reads like a numbered ticket stub.

## Tone

Refined minimalism with a botanical-green accent — calm, credible, and civic, like a well-run community club ledger rather than a casino.

## Differentiation

The number table is the centerpiece: monospace ticket-stub cells with three unambiguous states (available outline, reserved grey, paid solid green) that make the whole raffle readable at a glance.

## Color Palette

| Token      | OKLCH         | Role                                   |
| ---------- | ------------- | -------------------------------------- |
| background | 0.985 0.002 250 | Page canvas — near-white, cool neutral |
| foreground | 0.16 0.008 250  | Primary text — near-black              |
| card       | 1.0 0.0 0       | Elevated surfaces, forms, tables       |
| primary    | 0.42 0.11 152   | Deep forest green — CTAs, paid state   |
| accent     | 0.52 0.13 152   | Brighter green — highlights, active    |
| muted      | 0.955 0.004 250 | Reserved state, secondary fills        |

## Typography

- Display: Space Grotesk — headings, raffle title, section labels
- Body: DM Sans — paragraphs, forms, UI labels
- Mono: JetBrains Mono — ticket numbers, amounts, CBU/alias
- Scale: hero `text-4xl md:text-6xl font-bold tracking-tight`, h2 `text-2xl md:text-3xl font-bold`, label `text-xs font-semibold tracking-widest uppercase`, body `text-base`

## Elevation & Depth

Flat near-white canvas with crisp 1px borders; cards lift via `shadow-subtle`, interactive/selected surfaces via `shadow-elevated`; no glows.

## Structural Zones

| Zone    | Background      | Border   | Notes                                          |
| ------- | --------------- | -------- | ---------------------------------------------- |
| Header  | `bg-card`       | `border-b` | Sticky, small green logo mark, nav + admin      |
| Content | `bg-background` | —        | Alternating `bg-muted/40` sections for rhythm   |
| Footer  | `bg-muted/40`   | `border-t` | Muted meta, small type, generous padding        |

## Spacing & Rhythm

Spacious: `py-16 md:py-24` between sections, `gap-6` card grids, `gap-2` number cells, `space-y-4` inside forms.

## Component Patterns

- Buttons: `rounded-lg`, solid primary green for reserve/pay, outline for secondary, `hover:brightness-110`, `transition-smooth`
- Cards: `rounded-xl bg-card border shadow-subtle`, `p-6`, hover lifts to `shadow-elevated`
- Badges: pill `rounded-full`, green for paid, grey for reserved, outline for available
- Number cells: `rounded-md font-mono`, square aspect, status-coded

## Motion

- Entrance: `animate-fade-in` on page sections, 0.4s ease-out
- Hover: subtle lift + brightness on interactive elements, 0.3s
- Decorative: `animate-pulse-ring` on live availability indicator

## Constraints

- Palette stays white/black/grey with green accents only — no other hues except destructive red and warning amber
- No purple, no gradients on full-page backgrounds, no neon glow shadows
- Tokens only in components — never raw hex, `rgb()`, or arbitrary color classes
- Mobile-first responsive; number grid reflows to fewer columns on small screens

## Signature Detail

Ticket-stub number cells — monospace digits in square cells with a subtle inset border, where the paid state fills solid forest green, turning the grid into a legible ledger of the whole raffle.
