import { PocketIc, createIdentity } from "@dfinity/pic";
import type { Actor, CanisterFixture } from "@dfinity/pic";
import { afterAll, beforeAll, expect, it } from "vitest";

import { idlFactory } from "../../src/frontend/src/declarations/backend.did.js";
import type { _SERVICE } from "../../src/frontend/src/declarations/backend.did";
import { registerCaller } from "./test-utils";

const PIC_URL = process.env.POCKET_IC_URL ?? "";
const BACKEND_WASM = process.env.BACKEND_WASM ?? "";

let pic: PocketIc | undefined;
let actor: Actor<_SERVICE>;
let canisterId: CanisterFixture<_SERVICE>["canisterId"];

const admin = createIdentity("raffle-admin");
const visitor = createIdentity("raffle-visitor");

const settings = {
  title: "Rifa solidaria 2026",
  description: "Ayudanos a recaudar fondos.",
  pricePerNumber: 1500n,
  drawDate: 1_800_000_000_000_000_000n,
  prize: "Una bicicleta",
  payment: {
    alias: "rifa.solidaria",
    cbu: "0000000000000000000000",
    accountHolder: "María González",
    amount: 1500n,
  },
};

beforeAll(async () => {
  pic = await PocketIc.create(PIC_URL);
  ({ actor, canisterId } = await pic.setupCanister<_SERVICE>({
    idlFactory,
    wasm: BACKEND_WASM,
  }));
  // The first initialized caller becomes the administrator.
  actor = await registerCaller(actor, admin);
});

afterAll(async () => {
  await pic?.tearDown();
});

it("answers empty-state reads instead of trapping", async () => {
  await expect(actor.getNumberTable()).resolves.toEqual([]);
  await expect(actor.listParticipants()).resolves.toEqual([]);
});

it("round-trips settings, numbers, a reservation and a proof through the real canister", async () => {
  await actor.updateRaffleSettings(settings);
  await expect(actor.getRaffleSettings()).resolves.toEqual(settings);

  const numberId = await actor.createNumber(7n);
  await expect(actor.getNumberTable()).resolves.toContainEqual(
    expect.objectContaining({ id: numberId, value: 7n, state: { available: null } }),
  );

  const participantId = await actor.reserveNumbers(
    { fullName: "María González", phone: "1155555555", email: "maria@correo.com" },
    [7n],
  );
  const participants = await actor.listParticipants();
  expect(participants).toContainEqual(
    expect.objectContaining({
      id: participantId,
      fullName: "María González",
      numbers: [7n],
      totalAmount: 1500n,
      paymentStatus: { pending: null },
    }),
  );

  // The reserved number is no longer available.
  await expect(actor.getNumberTable()).resolves.toContainEqual(
    expect.objectContaining({ id: numberId, state: { reserved: null } }),
  );

  await actor.attachProof(participantId, new Uint8Array([1, 2, 3]));
  const withProof = await actor.listParticipants();
  expect(withProof[0].paymentStatus).toEqual({ proofSubmitted: null });
  expect(withProof[0].proof).toBeDefined();
});

it("rejects a reservation for an already reserved number", async () => {
  await expect(
    actor.reserveNumbers(
      { fullName: "Otro", phone: "1166666666", email: "otro@correo.com" },
      [7n],
    ),
  ).rejects.toThrow();
});

it("lets the administrator change a number's state and reset the raffle", async () => {
  const numberId = await actor.createNumber(9n);
  await actor.setNumberState(numberId, { paid: null });
  await expect(actor.getNumberTable()).resolves.toContainEqual(
    expect.objectContaining({ id: numberId, state: { paid: null } }),
  );

  await actor.resetRaffle();
  await expect(actor.listParticipants()).resolves.toEqual([]);
  const afterReset = await actor.getNumberTable();
  expect(afterReset.every((n) => "available" in n.state)).toBe(true);
});

it("rejects an anonymous caller from admin-only methods", async () => {
  const guest = pic!.createActor<_SERVICE>(idlFactory, canisterId);
  await expect(guest.listParticipants()).rejects.toThrow();
  await expect(guest.updateRaffleSettings(settings)).rejects.toThrow();
  await expect(guest.resetRaffle()).rejects.toThrow();
});

it("does not let a non-administrator read or edit participant data", async () => {
  const visitorActor = await registerCaller(
    pic!.createActor<_SERVICE>(idlFactory, canisterId),
    visitor,
  );
  await expect(visitorActor.listParticipants()).rejects.toThrow();
  await expect(
    visitorActor.updateParticipant(
      0n,
      { fullName: "Hack", phone: "1", email: "h@h.com" },
      { confirmed: null },
    ),
  ).rejects.toThrow();
  await expect(visitorActor.deleteParticipant(0n)).rejects.toThrow();
});
